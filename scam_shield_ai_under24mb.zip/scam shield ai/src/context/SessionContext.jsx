import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  getStoredSessionStats,
  saveSessionStats,
  getStoredHistory,
  saveHistory,
  clearSessionData,
  BENCHMARK_STATS,
  BENCHMARK_HISTORY,
} from '../utils/storage';

const SessionContext = createContext(null);

export function SessionProvider({ children }) {
  const [stats, setStats] = useState(() => getStoredSessionStats());
  const [history, setHistory] = useState(() => getStoredHistory());
  const [toasts, setToasts] = useState([]);

  // Toast Notification Manager
  const showToast = useCallback((message, type = 'info') => {
    const id = Date.now() + Math.random().toString(36).substring(2, 6);
    setToasts((prev) => [...prev, { id, message, type }]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  const removeToast = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Save changes to storage
  useEffect(() => {
    saveSessionStats(stats);
  }, [stats]);

  useEffect(() => {
    saveHistory(history);
  }, [history]);

  /**
   * Record new analysis in real time
   */
  const recordAnalysis = useCallback(
    ({ type, title, preview, riskLevel, score, categoriesCount = {}, indicatorsCount = 0, fullData = null }) => {
      setStats((prev) => {
        const updated = {
          ...prev,
          totalScans: prev.totalScans + 1,
          highRisk: riskLevel === 'HIGH' ? prev.highRisk + 1 : prev.highRisk,
          mediumRisk: riskLevel === 'MEDIUM' ? prev.mediumRisk + 1 : prev.mediumRisk,
          lowRisk: riskLevel === 'LOW' ? prev.lowRisk + 1 : prev.lowRisk,
          categories: { ...prev.categories },
          scansByType: {
            ...prev.scansByType,
            [type]: (prev.scansByType[type] || 0) + 1,
          },
          isBenchmarkLoaded: false,
        };

        // Increment matched categories
        Object.entries(categoriesCount).forEach(([catKey, count]) => {
          if (updated.categories[catKey] !== undefined) {
            updated.categories[catKey] += count;
          } else {
            updated.categories[catKey] = count;
          }
        });

        return updated;
      });

      // Add to non-sensitive session history
      const newEntry = {
        id: `scan-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
        type,
        title: title || `${type.toUpperCase()} Analysis`,
        preview: preview ? (preview.length > 90 ? preview.substring(0, 90) + '...' : preview) : '',
        riskLevel,
        score,
        timestamp: new Date().toISOString(),
        indicatorsCount,
        fullData,
      };

      setHistory((prev) => [newEntry, ...prev.slice(0, 29)]);
    },
    []
  );

  /**
   * Load Benchmark dataset for hackathon presentation / judges
   */
  const loadBenchmarkData = useCallback(() => {
    setStats(BENCHMARK_STATS);
    setHistory(BENCHMARK_HISTORY);
    showToast('Loaded Demo Benchmark Data into Dashboard!', 'success');
  }, [showToast]);

  /**
   * Reset session
   */
  const resetSession = useCallback(() => {
    const fresh = clearSessionData();
    setStats(fresh);
    setHistory([]);
    showToast('Session analytics have been reset.', 'info');
  }, [showToast]);

  return (
    <SessionContext.Provider
      value={{
        stats,
        history,
        recordAnalysis,
        loadBenchmarkData,
        resetSession,
        toasts,
        showToast,
        removeToast,
      }}
    >
      {children}
    </SessionContext.Provider>
  );
}

export function useSession() {
  const context = useContext(SessionContext);
  if (!context) {
    throw new Error('useSession must be used within a SessionProvider');
  }
  return context;
}
