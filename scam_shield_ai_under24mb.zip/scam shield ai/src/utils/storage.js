// Local Session Storage & Analytics Manager

const STORAGE_KEY = 'scamshield_session_stats_v1';
const HISTORY_KEY = 'scamshield_session_history_v1';

// Initial empty session state
const INITIAL_STATS = {
  totalScans: 0,
  highRisk: 0,
  mediumRisk: 0,
  lowRisk: 0,
  categories: {
    urgency_panic: 0,
    credential_theft: 0,
    malicious_links: 0,
    impersonation: 0,
    unrealistic_returns: 0,
    task_advance_fee: 0,
    insecure_url: 0,
    ponzi_mlm: 0,
  },
  scansByType: {
    message: 0,
    url: 0,
    claim: 0,
  },
  isBenchmarkLoaded: false,
};

// Benchmark dataset for Hackathon demonstration / Judge preview
export const BENCHMARK_STATS = {
  totalScans: 28,
  highRisk: 16,
  mediumRisk: 8,
  lowRisk: 4,
  categories: {
    urgency_panic: 14,
    credential_theft: 18,
    malicious_links: 12,
    impersonation: 10,
    unrealistic_returns: 9,
    task_advance_fee: 7,
    insecure_url: 8,
    ponzi_mlm: 6,
  },
  scansByType: {
    message: 14,
    url: 8,
    claim: 6,
  },
  isBenchmarkLoaded: true,
};

export const BENCHMARK_HISTORY = [
  {
    id: 'demo-hist-1',
    type: 'message',
    title: 'Fake Bank KYC SMS Phishing',
    preview: 'Dear SBI Customer, your bank account A/C ending in 4921 has been SUSPENDED...',
    riskLevel: 'HIGH',
    score: 85,
    timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
    indicatorsCount: 3,
  },
  {
    id: 'demo-hist-2',
    type: 'url',
    title: 'Phishing Domain Inspection',
    preview: 'http://sbi-secure-kyc-update-portal.xyz/login.php',
    riskLevel: 'HIGH',
    score: 95,
    timestamp: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
    indicatorsCount: 4,
  },
  {
    id: 'demo-hist-3',
    type: 'claim',
    title: 'Quantum AI 15% Daily Return',
    preview: 'Invest ₹10,000 today and get guaranteed 15% daily return with zero risk...',
    riskLevel: 'HIGH',
    score: 90,
    timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
    indicatorsCount: 3,
  },
  {
    id: 'demo-hist-4',
    type: 'url',
    title: 'Shortened Link Audit',
    preview: 'http://bit.ly/claim-free-prize-money-now',
    riskLevel: 'MEDIUM',
    score: 45,
    timestamp: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
    indicatorsCount: 2,
  },
  {
    id: 'demo-hist-5',
    type: 'message',
    title: 'Legitimate Bank Transaction SMS',
    preview: 'Your A/C XX4921 is debited by INR 1,450.00 towards Amazon India...',
    riskLevel: 'LOW',
    score: 0,
    timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    indicatorsCount: 0,
  },
];

/**
 * Loads session stats from sessionStorage or returns default
 */
export function getStoredSessionStats() {
  try {
    const saved = sessionStorage.getItem(STORAGE_KEY);
    if (saved) return JSON.parse(saved);
  } catch (e) {
    console.error('Session storage read error', e);
  }
  return INITIAL_STATS;
}

/**
 * Saves updated stats to sessionStorage
 */
export function saveSessionStats(stats) {
  try {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
  } catch (e) {
    console.error('Session storage write error', e);
  }
}

/**
 * Loads analysis history log (non-sensitive summaries)
 */
export function getStoredHistory() {
  try {
    const saved = sessionStorage.getItem(HISTORY_KEY);
    if (saved) return JSON.parse(saved);
  } catch (e) {
    console.error('Session history read error', e);
  }
  return [];
}

/**
 * Saves analysis history log
 */
export function saveHistory(history) {
  try {
    sessionStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 30)));
  } catch (e) {
    console.error('Session history write error', e);
  }
}

/**
 * Clears all session stats and history
 */
export function clearSessionData() {
  try {
    sessionStorage.removeItem(STORAGE_KEY);
    sessionStorage.removeItem(HISTORY_KEY);
  } catch (e) {
    console.error('Session clear error', e);
  }
  return INITIAL_STATS;
}
