// Message Heuristic Analysis Engine

export const MESSAGE_CATEGORIES = {
  URGENCY_PANIC: {
    id: 'urgency_panic',
    name: 'Artificial Urgency & Fear Tactics',
    nameHi: 'कृत्रिम घबराहट और तात्कालिकता',
    color: 'rose',
    weight: 25,
  },
  CREDENTIAL_THEFT: {
    id: 'credential_theft',
    name: 'Credential & OTP Harvesting',
    nameHi: 'OTP और पासवर्ड चोरी के प्रयास',
    color: 'red',
    weight: 35,
  },
  MALICIOUS_LINKS: {
    id: 'malicious_links',
    name: 'Suspicious Links / APK Downloads',
    nameHi: 'संदिग्ध लिंक या APK फाइल',
    color: 'amber',
    weight: 25,
  },
  IMPERSONATION: {
    id: 'impersonation',
    name: 'Authority / Bank Impersonation',
    nameHi: 'बैंक या पुलिस अधिकारी का भेष',
    color: 'purple',
    weight: 25,
  },
  UNREALISTIC_RETURNS: {
    id: 'unrealistic_returns',
    name: 'Guaranteed / Unrealistic Returns',
    nameHi: 'अवास्तविक या गारंटीड मुनाफे का वादा',
    color: 'amber',
    weight: 25,
  },
  TASK_ADVANCE_FEE: {
    id: 'task_advance_fee',
    name: 'Advance Fee & Task Trap',
    nameHi: 'अग्रिम शुल्क और पार्ट-टाइम जॉब ट्रैप',
    color: 'orange',
    weight: 20,
  },
};

const MESSAGE_RULES = [
  // 1. Credential & OTP Harvesting (Highest Danger)
  {
    regex: /\b(share\s*otp|send\s*otp|enter\s*otp|otp\s*verification|provide\s*otp|verify\s*otp|4-digit\s*pin|6-digit\s*pin|upi\s*pin|cvv\s*number|debit\s*card\s*details|card\s*expiry|atm\s*pin|netbanking\s*password|login\s*credentials)\b/gi,
    category: MESSAGE_CATEGORIES.CREDENTIAL_THEFT,
    severity: 'critical',
    titleEn: 'Direct Request for Secret Credentials (OTP/PIN/CVV)',
    titleHi: 'गुप्त क्रेडेंशियल्स (OTP/PIN/CVV) की सीधी मांग',
    descEn: 'Legitimate financial institutions NEVER ask for your OTP, UPI PIN, or CVV. Sharing this grants attackers full access to withdraw your funds.',
    descHi: 'वास्तविक बैंक कभी भी कॉल या SMS पर आपका OTP, UPI पिन या CVV नहीं मांगते। इसे साझा करने पर आपके खाते से पैसे कट सकते हैं।',
  },
  {
    regex: /\b(aadhaar\s*otp|pan\s*verification\s*otp|link\s*aadhaar\s*immediately|update\s*pan\s*card\s*now)\b/gi,
    category: MESSAGE_CATEGORIES.CREDENTIAL_THEFT,
    severity: 'high',
    titleEn: 'Identity Document / Aadhaar OTP Harvesting',
    titleHi: 'पहचान दस्तावेज / आधार OTP चोरी की कोशिश',
    descEn: 'Scammers frequently request Aadhaar OTPs under the guise of PAN-Aadhaar linking to take out unauthorized loans or clone SIMs.',
    descHi: 'धोखेबाज पैन-आधार लिंक के नाम पर आधार OTP मांगकर अनधिकृत लोन या सिम क्लोनिंग करते हैं।',
  },

  // 2. Urgency & Fear Tactics
  {
    regex: /\b(account\s*(will\s*be\s*|is\s*)?(blocked|suspended|deactivated|frozen|terminated|closed)\s*(within|in|today|tonight|immediately|24\s*hours|2\s*hours)?)\b/gi,
    category: MESSAGE_CATEGORIES.URGENCY_PANIC,
    severity: 'high',
    titleEn: 'Account Deactivation Threat / Artificial Urgency',
    titleHi: 'खाता बंद होने की झूठी धमकी / कृत्रिम घबराहट',
    descEn: 'Creates sudden panic to bypass rational judgment so you click links or transfer money in a rush.',
    descHi: 'यह तुरंत घबराहट पैदा करता है ताकि आप बिना सोचे-समझे लिंक पर क्लिक करें।',
  },
  {
    regex: /\b(electricity\s*(will\s*be\s*|is\s*)?disconnected\s*(tonight|today|by\s*\d+\s*pm|within\s*\d+\s*hours))\b/gi,
    category: MESSAGE_CATEGORIES.URGENCY_PANIC,
    severity: 'high',
    titleEn: 'Utility / Electricity Disconnection Scam Pattern',
    titleHi: 'बिजली बिल डिस्कनेक्शन फर्जी पैटर्न',
    descEn: 'A notorious scam where victims are threatened with immediate power cutoff and directed to call a fraudulent number or install a helper APK.',
    descHi: 'बिजली कटने का डर दिखाकर एक फर्जी नंबर पर कॉल करने या APK डाउनलोड करने के लिए कहा जाता है।',
  },
  {
    regex: /\b(immediate\s*action\s*required|act\s*now|last\s*warning|final\s*notice|legal\s*notice|warrant\s*issued|arrest\s*warrant|court\s*order|case\s*registered)\b/gi,
    category: MESSAGE_CATEGORIES.URGENCY_PANIC,
    severity: 'high',
    titleEn: 'Coercive Legal / Arrest Threat Pattern',
    titleHi: 'कानूनी कार्रवाई / गिरफ्तारी की फर्जी धमकी',
    descEn: 'Uses fake legal authority or arrest threats to intimidate victims into sending money immediately.',
    descHi: 'फर्जी कानूनी नोटिस या गिरफ्तारी का डर दिखाकर पीड़ितों से जबरन पैसे ट्रांसफर कराए जाते हैं।',
  },

  // 3. Authority & Impersonation
  {
    regex: /\b(rbi\s*officer|reserve\s*bank\s*of\s*india|cyber\s*crime\s*department|cbi\s*officer|customs\s*officer|mumbai\s*police|delhi\s*police|trai\s*department|sbi\s*manager|hdfc\s*security\s*team)\b/gi,
    category: MESSAGE_CATEGORIES.IMPERSONATION,
    severity: 'high',
    titleEn: 'Law Enforcement / Regulatory Impersonation',
    titleHi: 'पुलिस, सीबीआई या बैंक अधिकारी का फर्जी नाम',
    descEn: 'Government agencies and law enforcement never contact citizens via WhatsApp, Telegram, or SMS demanding money or private video calls.',
    descHi: 'सरकारी एजेंसियां या पुलिस कभी भी व्हाट्सएप या फोन पर पैसे की मांग नहीं करती हैं।',
  },
  {
    regex: /\b(fedex\s*courier|customs\s*parcel|narcotics\s*found|illegal\s*passport|drugs\s*in\s*courier|parcel\s*detained)\b/gi,
    category: MESSAGE_CATEGORIES.IMPERSONATION,
    severity: 'high',
    titleEn: 'Customs / Courier Drug Parcel Scam Pattern',
    titleHi: 'कस्टम्स पार्सल / अवैध सामान की झूठी कहानी',
    descEn: 'Claims a parcel in your name contains illegal substances, connecting you to fake police on video call to extort money.',
    descHi: 'दावा किया जाता है कि आपके नाम के पार्सल में अवैध सामान मिला है और वीडियो कॉल पर पैसे वसूले जाते हैं।',
  },

  // 4. Malicious Links & APKs
  {
    regex: /\b(download\s*apk|install\s*apk|\.apk|\.xyz|\.top|\.click|\.work|\.loan|bit\.ly|tinyurl\.com|is\.gd|cutt\.ly|t\.co|t\.me\/[a-zA-Z0-9_]+)\b/gi,
    category: MESSAGE_CATEGORIES.MALICIOUS_LINKS,
    severity: 'high',
    titleEn: 'Unofficial APK File / Shortened Malicious Link',
    titleHi: 'अनाधिकृत APK फाइल / छोटा संदिग्ध लिंक',
    descEn: 'Directs users to download APKs or visit obfuscated URLs designed to steal credentials or read OTP SMS messages silently.',
    descHi: 'संदिग्ध APK या लिंक आपके फोन में इंस्टॉल होकर गोपनीय OTP और संदेश चुरा सकते हैं।',
  },
  {
    regex: /\b(click\s*here\s*to\s*(update|verify|claim|login|reactivate|unblock)|visit\s*http[s]?:\/\/[^\s]+)\b/gi,
    category: MESSAGE_CATEGORIES.MALICIOUS_LINKS,
    severity: 'medium',
    titleEn: 'Call-to-Action with External Verification Link',
    titleHi: 'अनाधिकृत लिंक पर सत्यापन की मांग',
    descEn: 'Banks never send direct links asking you to enter login passwords or update KYC.',
    descHi: 'बैंक कभी भी लॉगिन पासवर्ड डालने या KYC अपडेट करने के लिए सीधे लिंक नहीं भेजते।',
  },

  // 5. Unrealistic Returns & Crypto
  {
    regex: /\b(guaranteed\s*(returns|profit|income)|double\s*your\s*money|100%\s*risk\s*free|500%\s*profit|10x\s*returns|zero\s*loss|daily\s*fixed\s*return|passive\s*income\s*guarantee)\b/gi,
    category: MESSAGE_CATEGORIES.UNREALISTIC_RETURNS,
    severity: 'high',
    titleEn: 'Guaranteed / Zero-Risk Profit Promise',
    titleHi: 'बिना जोखिम के गारंटीड मुनाफे का असंभव दावा',
    descEn: 'No legitimate investment can legally guarantee fixed high returns without risk. This is the hallmark of a Ponzi or fraudulent scheme.',
    descHi: 'कोई भी वास्तविक निवेश बिना जोखिम के भारी लाभ की गारंटी नहीं दे सकता। यह पोंजी स्कीम का स्पष्ट संकेत है।',
  },

  // 6. Part-Time Job / Advance Fee Traps
  {
    regex: /\b(like\s*youtube\s*videos|rate\s*hotels\s*on\s*google|earn\s*(\d{3,5})\s*daily|part-time\s*job\s*from\s*home|telegram\s*task|prepaid\s*task|security\s*deposit\s*required|pay\s*registration\s*fee|kbc\s*lucky\s*winner|congratulations\s*you\s*won\s*lottery|claim\s*your\s*car\s*prize)\b/gi,
    category: MESSAGE_CATEGORIES.TASK_ADVANCE_FEE,
    severity: 'high',
    titleEn: 'Part-Time Task Trap / Advance Fee Lottery Scheme',
    titleHi: 'पार्ट-टाइम टास्क फ्रॉड / अग्रिम शुल्क लॉटरी झांसा',
    descEn: 'Lures users with easy tasks (liking videos) and small initial payouts, then traps them into depositing large amounts to withdraw fake earnings.',
    descHi: 'शुरुआत में आसान काम के बहाने छोटे पैसे दिए जाते हैं, फिर बड़ी रकम निकालने के नाम पर अग्रिम जमा कराया जाता है।',
  },
];

// Legitimate bank alert patterns that indicate safe transactions
const SAFE_PATTERNS = [
  /\b(a\/c\s*[\*x\d]+\s*(debited|credited)\s*by\s*rs|inr\s*[\d,]+(\.\d{2})?\s*(debited|credited)|avail\s*bal\s*[:\s]*rs|if\s*not\s*done\s*by\s*you,\s*(sms|call)\s*block)\b/gi,
  /\b(otp\s*for\s*txn\s*of\s*rs\s*[\d,]+\s*at\s*[a-zA-Z0-9\s]+\s*is\s*\d+\.\s*never\s*share\s*otp)\b/gi,
];

/**
 * Analyzes message text using comprehensive heuristic pattern matching
 * @param {string} text - Message text to inspect
 * @returns {object} Detailed analysis results with highlights and recommendations
 */
export function analyzeMessage(text) {
  if (!text || !text.trim()) {
    return {
      isValid: false,
      score: 0,
      riskLevel: 'LOW',
      findings: [],
      matchedTokens: [],
      categoriesCount: {},
      summary: 'No message entered.',
      recommendations: [],
    };
  }

  const cleanText = text.trim();
  const matchedTokens = [];
  const findings = [];
  const categoriesCount = {};

  let rawScore = 0;

  // Run heuristic rules
  MESSAGE_RULES.forEach((rule) => {
    // Reset regex lastIndex
    rule.regex.lastIndex = 0;
    let match;
    let ruleMatched = false;

    while ((match = rule.regex.exec(cleanText)) !== null) {
      ruleMatched = true;
      const matchedPhrase = match[0];
      const start = match.index;
      const end = start + matchedPhrase.length;

      // Avoid duplicate overlap tokens
      const isOverlapping = matchedTokens.some(
        (t) => (start >= t.start && start < t.end) || (end > t.start && end <= t.end)
      );

      if (!isOverlapping) {
        matchedTokens.push({
          phrase: matchedPhrase,
          start,
          end,
          category: rule.category.name,
          categoryHi: rule.category.nameHi,
          categoryId: rule.category.id,
          severity: rule.severity,
          titleEn: rule.titleEn,
          titleHi: rule.titleHi,
        });
      }
    }

    if (ruleMatched) {
      categoriesCount[rule.category.id] = (categoriesCount[rule.category.id] || 0) + 1;
      findings.push({
        category: rule.category.name,
        categoryHi: rule.category.nameHi,
        categoryId: rule.category.id,
        severity: rule.severity,
        titleEn: rule.titleEn,
        titleHi: rule.titleHi,
        descEn: rule.descEn,
        descHi: rule.descHi,
      });

      // Weight scoring
      if (rule.severity === 'critical') rawScore += 45;
      else if (rule.severity === 'high') rawScore += 30;
      else rawScore += 15;
    }
  });

  // Check for safe transaction markers
  let safeMarkerCount = 0;
  SAFE_PATTERNS.forEach((pattern) => {
    pattern.lastIndex = 0;
    if (pattern.test(cleanText)) {
      safeMarkerCount += 1;
    }
  });

  // Deduct score if it's a standard transactional alert with no urgent links or OTP requests
  if (safeMarkerCount > 0 && findings.length === 0) {
    rawScore = 0;
  } else if (safeMarkerCount > 0 && rawScore < 30) {
    rawScore = Math.max(0, rawScore - 20);
  }

  // Cap score between 0 and 100
  const score = Math.min(100, Math.max(0, rawScore));

  let riskLevel = 'LOW';
  if (score >= 60) riskLevel = 'HIGH';
  else if (score >= 25) riskLevel = 'MEDIUM';

  // Generate actionable recommendations
  const recommendations = [];
  if (riskLevel === 'HIGH') {
    recommendations.push({
      en: 'DO NOT click any links, open APK attachments, or scan QR codes provided in this message.',
      hi: 'इस संदेश में दिए गए किसी भी लिंक पर क्लिक न करें, न ही कोई APK फाइल खोलें।',
    });
    recommendations.push({
      en: 'NEVER share OTP, PIN, passwords, or bank details under any circumstances.',
      hi: 'किसी भी परिस्थिति में अपना OTP, पिन, पासवर्ड या बैंक विवरण साझा न करें।',
    });
    recommendations.push({
      en: 'If threatened with account block or police arrest, verify independently by dialing your bank’s official helpline or 1930 Cyber Cell.',
      hi: 'यदि खाता बंद होने या पुलिस गिरफ्तारी की धमकी मिले, तो अपने बैंक की आधिकारिक हेल्पलाइन या 1930 पर संपर्क करें।',
    });
    recommendations.push({
      en: 'Report and block the sender on WhatsApp / SMS and submit details to cybercrime.gov.in.',
      hi: 'प्रेषक को तुरंत ब्लॉक करें और cybercrime.gov.in पर रिपोर्ट करें।',
    });
  } else if (riskLevel === 'MEDIUM') {
    recommendations.push({
      en: 'Exercise caution: Verify the sender number or email against official institution records.',
      hi: 'सावधानी बरतें: प्रेषक के नंबर या ईमेल की आधिकारिक वेबसाइट से पुष्टि करें।',
    });
    recommendations.push({
      en: 'Do not make any advance payments, security deposits, or registration fee transfers.',
      hi: 'कोई भी अग्रिम भुगतान, सुरक्षा जमा या पंजीकरण शुल्क ट्रांसफर न करें।',
    });
    recommendations.push({
      en: 'Check website URLs manually in a browser instead of tapping embedded SMS links.',
      hi: 'SMS में दिए गए लिंक पर टैप करने के बजाय ब्राउज़र में आधिकारिक URL स्वयं टाइप करें।',
    });
  } else {
    recommendations.push({
      en: 'No major scam red flags detected in the text.',
      hi: 'संदेश में कोई बड़ा घोटाला संकेतक नहीं पाया गया।',
    });
    recommendations.push({
      en: 'Always maintain standard security hygiene: never share UPI PIN while receiving money.',
      hi: 'हमेशा बुनियादी सुरक्षा बनाए रखें: पैसे प्राप्त करते समय कभी भी UPI पिन दर्ज न करें।',
    });
  }

  // Sort matched tokens by start index
  matchedTokens.sort((a, b) => a.start - b.start);

  return {
    isValid: true,
    score,
    riskLevel,
    findings,
    matchedTokens,
    categoriesCount,
    textLength: cleanText.length,
    recommendations,
  };
}

// Preset test scenarios for user and judges to test immediately
export const SAMPLE_MESSAGES = [
  {
    id: 'sample-kyc-bank',
    labelEn: 'Fake Bank KYC Suspension',
    labelHi: 'फर्जी बैंक KYC निलंबन',
    riskLevel: 'HIGH',
    text: 'Dear SBI Customer, your bank account A/C ending in 4921 has been SUSPENDED due to incomplete KYC! To avoid permanent deactivation, click immediately on http://sbi-secure-kyc-update.xyz/login to update your PAN and share Aadhaar OTP within 2 hours.',
  },
  {
    id: 'sample-crypto-return',
    labelEn: 'Crypto 500% Guaranteed Return',
    labelHi: 'क्रिप्टो 500% गारंटीड लाभ',
    riskLevel: 'HIGH',
    text: '🎉 Special VIP Offer: Invest ₹10,000 today in our automated AI Crypto bot and get guaranteed ₹50,000 in 7 days! 100% risk free with zero loss guarantee. Join our Telegram VIP group t.me/vip_crypto_doubler now. Only 3 spots left!',
  },
  {
    id: 'sample-digital-arrest',
    labelEn: 'Digital Arrest / Police Threat',
    labelHi: 'डिजिटल अरेस्ट / पुलिस धमकी',
    riskLevel: 'HIGH',
    text: 'URGENT NOTICE from Mumbai Cyber Crime Department: A parcel containing illegal narcotics and fake passports has been intercepted under your Aadhaar number. Arrest warrant issued. Call Inspector Sharma immediately on WhatsApp or face legal action.',
  },
  {
    id: 'sample-job-task',
    labelEn: 'Part-Time YouTube Rating Job',
    labelHi: 'पार्ट-टाइम यूट्यूब रेटिंग जॉब',
    riskLevel: 'HIGH',
    text: 'Earn ₹3,000 to ₹8,000 daily from home by simply liking YouTube videos and rating hotels on Google! Telegram task available. First complete 3 prepaid tasks with ₹1,000 security deposit to unlock your daily commission payout.',
  },
  {
    id: 'sample-lottery-prize',
    labelEn: 'Lottery / Advance Fee Scam',
    labelHi: 'लॉटरी / अग्रिम शुल्क झांसा',
    riskLevel: 'HIGH',
    text: 'Congratulations! You have been selected as the KBC Lucky Winner of ₹25,00,000 cash prize. To claim your prize money, please pay registration fee and GST of ₹2,500 to our official account immediately.',
  },
  {
    id: 'sample-safe-bank',
    labelEn: 'Legitimate Bank Alert (Safe)',
    labelHi: 'असली बैंक अलर्ट (सुरक्षित)',
    riskLevel: 'LOW',
    text: 'Your A/C XX4921 is debited by INR 1,450.00 on 03-Oct-26 towards Amazon India. Avail Bal: INR 34,210.50. If not done by you, SMS BLOCK to 567676 or call 1800112211.',
  },
];
