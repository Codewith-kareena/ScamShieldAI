// Financial Claim & Scheme Verifier Engine

const CLAIM_RULES = [
  // 1. Guaranteed Returns & Risk-Free Claims
  {
    regex: /\b(guaranteed\s*(returns|profit|income|payout|yield)|100%\s*(safe|risk\s*free|profit|guarantee)|zero\s*risk|no\s*risk|capital\s*guarantee|loss\s*proof|never\s*lose)\b/gi,
    severity: 'critical',
    category: 'GUARANTEED_RETURNS',
    titleEn: 'Zero-Risk & Guaranteed Profit Claim',
    titleHi: 'शून्य जोखिम और गारंटीड मुनाफे का दावा',
    descEn: 'In legitimate financial markets, risk and return are inextricably linked. Legally, no market-linked financial instrument can guarantee profits without risk. This is the primary hallmark of fraudulent schemes.',
    descHi: 'वित्तीय बाजार में लाभ और जोखिम हमेशा जुड़े होते हैं। कोई भी वैध निवेश बिना जोखिम के मुनाफे की गारंटी नहीं दे सकता। यह पोंजी स्कीम का मुख्य संकेत है।',
  },

  // 2. Unrealistic Yield Rates (Daily / Weekly doubling)
  {
    regex: /\b(double\s*your\s*money|triple\s*your\s*investment|\b(\d{1,3})%\s*(daily|per\s*day|weekly|per\s*week|monthly|in\s*\d+\s*(days|hours|minutes))|(\d+)x\s*returns|500%\s*profit|1000%\s*gain)\b/gi,
    severity: 'critical',
    category: 'UNREALISTIC_YIELD',
    titleEn: 'Mathematically Impossible Yield Rate',
    titleHi: 'गणितीय रूप से असंभव रिटर्न दर',
    descEn: 'Promising daily or weekly compounded returns (e.g. 10% daily or doubling in 10 days) is economically impossible. For perspective, legitimate broad market indices average 12-14% annually with volatility.',
    descHi: 'दैनिक या साप्ताहिक रिटर्न का वादा आर्थिक रूप से असंभव है। तुलना के लिए, सुरक्षित बैंक FD सालाना 7% और शेयर बाजार औसतन 12-14% वार्षिक रिटर्न देते हैं।',
  },

  // 3. MLM / Ponzi Referral Traps
  {
    regex: /\b(refer\s*\d+\s*(friends|people|members)|referral\s*bonus|binary\s*plan|mlm|matrix\s*income|downline\s*earnings|direct\s*sponsor\s*commission|bring\s*investors)\b/gi,
    category: 'PONZI_MLM',
    severity: 'high',
    titleEn: 'Multi-Level Referral / Ponzi Compensation Mechanics',
    titleHi: 'मल्टी-लेवल रेफरल / पोंजी स्कीम तंत्र',
    descEn: 'Scheme relies on paying existing members using money deposited by newly recruited members, rather than generating actual economic value or business revenue.',
    descHi: 'यह योजना नए लोगों के पैसों से पुराने लोगों को भुगतान करती है, जो अंततः ढह जाती है और पैसे डूब जाते हैं।',
  },

  // 4. Secret AI Bots / Insider Tips (FOMO)
  {
    regex: /\b(secret\s*ai\s*bot|automated\s*trading\s*bot\s*with\s*100%\s*win|insider\s*tips|vip\s*telegram\s*group|jackpot\s*stock|operator\s*tips|sure\s*shot\s*call|100%\s*accuracy)\b/gi,
    category: 'INSIDER_FOMO',
    severity: 'high',
    titleEn: 'Unregulated Secret Algorithm / VIP Insider Tips',
    titleHi: 'अनाधिकृत गुप्त एल्गोरिदम / वीआईपी टिप्स का झांसा',
    descEn: 'Touting "secret bots" or "sure-shot operator calls" violates SEBI/SEC regulations. Operating unregistered advisory or charging VIP fees on Telegram is illegal.',
    descHi: 'टेलीग्राम पर "VIP टिप्स" या "100% सटीक बॉट" बेचना अवैध है और सेबी नियमों का उल्लंघन है।',
  },

  // 5. Work from Home / Prepaid Task Traps
  {
    regex: /\b(like\s*youtube\s*videos|hotel\s*review\s*task|earn\s*\d+\s*daily\s*from\s*mobile|prepaid\s*deposit\s*task|security\s*fee\s*to\s*withdraw)\b/gi,
    category: 'TASK_TRAP',
    severity: 'high',
    titleEn: 'Prepaid Task / Advance Fee Extraction Mechanism',
    titleHi: 'प्रीपेड टास्क / अग्रिम शुल्क वसूली तंत्र',
    descEn: 'Requires upfront capital deposit under the pretext of unlocking higher commissions. The victim is never allowed to withdraw their principal.',
    descHi: 'कमीशन निकालने के बहाने पहले पैसे जमा कराए जाते हैं, और बाद में मूल राशि भी हड़प ली जाती है।',
  },

  // 6. Unregulated Payment Channels
  {
    regex: /\b(pay\s*via\s*crypto|usdt\s*transfer|personal\s*upi|cash\s*deposit\s*to\s*account|western\s*union|gift\s*card)\b/gi,
    category: 'UNREGULATED_PAYMENT',
    severity: 'high',
    titleEn: 'Irreversible / Unregulated Payment Channels',
    titleHi: 'अपरिवर्तनीय / गैर-विनियमित भुगतान चैनल',
    descEn: 'Demands payment via cryptocurrency (USDT) or personal UPI accounts to avoid banking fraud tracing and make chargebacks impossible.',
    descHi: 'क्रिप्टो या व्यक्तिगत UPI के माध्यम से भुगतान की मांग की जाती है ताकि पैसे वापस न पाए जा सकें।',
  },
];

// Legitimate compliance markers
const LEGIT_COMPLIANCE_PATTERNS = [
  /\b(sebi\s*registered|amfi\s*registered|rbi\s*regulated|arn-\d+|ina\d+|investments\s*are\s*subject\s*to\s*market\s*risks|read\s*all\s*scheme\s*related\s*documents)\b/gi,
];

/**
 * Evaluates financial claims, advertisements, and scheme descriptions
 * @param {string} claimText - Claim text to audit
 * @returns {object} Comprehensive claim evaluation
 */
export function analyzeClaim(claimText) {
  if (!claimText || !claimText.trim()) {
    return {
      isValid: false,
      score: 0,
      riskLevel: 'LOW',
      findings: [],
      missingComplianceChecklist: [],
      benchmarkComparison: null,
    };
  }

  const cleanClaim = claimText.trim();
  const findings = [];
  let score = 0;

  CLAIM_RULES.forEach((rule) => {
    rule.regex.lastIndex = 0;
    if (rule.regex.test(cleanClaim)) {
      if (rule.severity === 'critical') score += 40;
      else if (rule.severity === 'high') score += 25;
      else score += 15;

      findings.push({
        category: rule.category,
        severity: rule.severity,
        titleEn: rule.titleEn,
        titleHi: rule.titleHi,
        descEn: rule.descEn,
        descHi: rule.descHi,
      });
    }
  });

  // Check for presence of regulatory disclosures
  let hasRegulatedDisclaimer = false;
  LEGIT_COMPLIANCE_PATTERNS.forEach((pat) => {
    pat.lastIndex = 0;
    if (pat.test(cleanClaim)) {
      hasRegulatedDisclaimer = true;
    }
  });

  // If claim sounds high-return but lacks standard market risk disclaimers, flag compliance missing
  const missingComplianceChecklist = [
    {
      itemEn: 'Official Regulatory Registration (SEBI / SEC / RBI / FCA license)',
      itemHi: 'आधिकारिक नियामक पंजीकरण (सेबी / आरबीआई लाइसेंस)',
      status: hasRegulatedDisclaimer ? 'verified' : 'missing',
      descEn: hasRegulatedDisclaimer ? 'Registration or regulatory body mentioned.' : 'No verified regulatory license or registration ID found in claim text.',
      descHi: hasRegulatedDisclaimer ? 'पंजीकरण का उल्लेख मिला।' : 'दावे में कोई सत्यापित नियामक लाइसेंस या पंजीकरण संख्या नहीं मिली।',
    },
    {
      itemEn: 'Mandatory Market Risk Warning Disclosure',
      itemHi: 'अनिवार्य बाजार जोखिम चेतावनी अस्वीकरण',
      status: hasRegulatedDisclaimer ? 'verified' : 'missing',
      descEn: hasRegulatedDisclaimer ? 'Risk disclaimer present.' : 'Missing statutory disclaimer: "Investments are subject to market risks, read all scheme documents carefully."',
      descHi: hasRegulatedDisclaimer ? 'जोखिम चेतावनी मौजूद है।' : 'वैधानिक चेतावनी गायब है: "निवेश बाजार जोखिमों के अधीन हैं।"',
    },
    {
      itemEn: 'Audited Financial Track Record / Prospectus',
      itemHi: 'ऑडिटेड वित्तीय रिकॉर्ड / योजना प्रॉस्पेक्टस',
      status: 'missing',
      descEn: 'Scheme does not provide publicly verifiable balance sheets, fund manager audits, or SEBI Offer Documents.',
      descHi: 'योजना कोई सार्वजनिक रूप से सत्यापित बैलेंस शीट या ऑडिट रिपोर्ट प्रदान नहीं करती है।',
    },
    {
      itemEn: 'Regulated Corporate Escrow / Depository Account',
      itemHi: 'विनियमित कॉर्पोरेट एस्क्रो खाता',
      status: cleanClaim.toLowerCase().includes('usdt') || cleanClaim.toLowerCase().includes('telegram') ? 'missing' : 'warning',
      descEn: 'Payments routed via personal UPI/crypto instead of registered custodian accounts.',
      descHi: 'भुगतान पंजीकृत कस्टोडियन के बजाय व्यक्तिगत खातों या क्रिप्टो में मंगाया जाता है।',
    },
  ];

  if (findings.length > 0 && !hasRegulatedDisclaimer) {
    score += 15;
  }

  // Cap score
  const finalScore = Math.min(100, Math.max(0, score));
  let riskLevel = 'LOW';
  if (finalScore >= 50) riskLevel = 'HIGH';
  else if (finalScore >= 20) riskLevel = 'MEDIUM';

  // Benchmark yield reference for educational comparison
  const benchmarkComparison = {
    rbiRepoRate: '6.5% p.a.',
    bankFdRate: '6.5% - 7.5% p.a.',
    equityMarketAvg: '12.0% - 14.0% p.a. (Volatile)',
    claimedSchemeAssessment: riskLevel === 'HIGH' 
      ? 'Mathematically and economically unsustainable yield (Ponzi / Fraud characteristics)' 
      : 'Within reasonable market parameters or standard disclosure format',
    claimedSchemeAssessmentHi: riskLevel === 'HIGH' 
      ? 'गणितीय और आर्थिक रूप से अव्यावहारिक रिटर्न (पोंजी/धोखाधड़ी के लक्षण)' 
      : 'उचित बाजार मापदंडों के भीतर या मानक प्रकटीकरण प्रारूप',
  };

  const verificationSteps = [
    {
      stepEn: 'Check SEBI Intermediary Registry',
      stepHi: 'सेबी मध्यस्थ रजिस्ट्री की जांच करें',
      detailEn: 'Visit sebi.gov.in and verify if the advisory or entity possesses a valid SEBI Research Analyst (RA) or Investment Advisor (RIA) registration number.',
      detailHi: 'sebi.gov.in पर जाएं और जांचें कि क्या संस्था के पास वैध सेबी रिसर्च एनालिस्ट (RA) या RIA नंबर है।',
    },
    {
      stepEn: 'Cross-Check RBI Sachet Portal',
      stepHi: 'आरबीआई सचेत पोर्टल पर जांचें',
      detailEn: 'Use sachet.rbi.org.in to check if the company is authorized to accept public deposits or if it has been blacklisted for unauthorized deposit-taking.',
      detailHi: 'sachet.rbi.org.in पर जांचें कि क्या कंपनी जनता से जमा राशि स्वीकार करने के लिए अधिकृत है।',
    },
    {
      stepEn: 'Verify Payment Beneficiary Name',
      stepHi: 'भुगतान प्राप्तकर्ता के नाम की पुष्टि करें',
      detailEn: 'Ensure funds are only transferred to a SEBI-registered broker/mutual fund corporate bank account, NEVER to an individual person’s UPI handle or crypto wallet.',
      detailHi: 'सुनिश्चित करें कि धनराशि केवल पंजीकृत कॉर्पोरेट बैंक खाते में भेजी जाए, कभी भी किसी व्यक्ति के UPI या क्रिप्टो में नहीं।',
    },
    {
      stepEn: 'Demand Audited Scheme Information Document (SID)',
      stepHi: 'ऑडिटेड स्कीम इंफॉर्मेशन डॉक्यूमेंट (SID) मांगें',
      detailEn: 'Always insist on reading the official Scheme Information Document and Key Information Memorandum (KIM) before allocating funds.',
      detailHi: 'पैसे लगाने से पहले हमेशा आधिकारिक स्कीम इंफॉर्मेशन डॉक्यूमेंट पढ़ने पर जोर दें।',
    },
  ];

  return {
    isValid: true,
    score: finalScore,
    riskLevel,
    findings,
    missingComplianceChecklist,
    benchmarkComparison,
    verificationSteps,
  };
}

// Preset Financial Claims to test
export const SAMPLE_CLAIMS = [
  {
    id: 'sample-claim-daily-15',
    labelEn: 'Guaranteed 15% Daily Return',
    labelHi: 'गारंटीड 15% दैनिक रिटर्न',
    riskLevel: 'HIGH',
    text: 'Invest ₹10,000 today in our Automated Quantum AI Trading Algorithm and get guaranteed 15% daily return with zero risk! Double your money in 7 days. 100% loss-proof capital guarantee!',
  },
  {
    id: 'sample-claim-telegram-tips',
    labelEn: 'VIP Stock Insider Tips (Telegram)',
    labelHi: 'VIP स्टॉक इनसाइडर टिप्स (टेलीग्राम)',
    riskLevel: 'HIGH',
    text: 'Exclusive Pre-IPO and 100% Sure-Shot Jackpot Stock Tips! Join our VIP Telegram channel for ₹5,000/month. Operator insider calls with 500% profit guarantee. Transfer fees to personal UPI @investor89.',
  },
  {
    id: 'sample-claim-prepaid-task',
    labelEn: 'Prepaid Work-from-Home Task',
    labelHi: 'प्रीपेड वर्क-फ्रॉम-होम टास्क',
    riskLevel: 'HIGH',
    text: 'Work from home: Earn ₹5,000 per day by rating hotels and liking YouTube videos. To start receiving daily commissions, deposit ₹2,000 refundable security deposit to unlock VIP Tier 1.',
  },
  {
    id: 'sample-claim-mlm-pyramid',
    labelEn: 'Multi-Level Pyramid Referral',
    labelHi: 'मल्टी-लेवल पिरामिड रेफरल',
    riskLevel: 'HIGH',
    text: 'Revolutionary Decentralized Smart Contract Income: Deposit 100 USDT, refer 3 direct members and receive 30% binary matrix commission from all downline deposits for lifetime passive income.',
  },
  {
    id: 'sample-claim-safe-sip',
    labelEn: 'Standard Regulated Mutual Fund SIP (Safe)',
    labelHi: 'मानक म्यूचुअल फंड SIP (सुरक्षित)',
    riskLevel: 'LOW',
    text: 'Invest in Large Cap Equity Mutual Fund via monthly SIP. 5-year historical annualized return is 13.5% p.a. SEBI Registered Mutual Fund (ARN-10293). Investments in securities market are subject to market risks. Read all scheme related documents carefully.',
  },
];
