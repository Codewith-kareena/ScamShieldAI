// URL Security Heuristic Inspector Engine

const SUSPICIOUS_TLDS = [
  '.xyz', '.top', '.click', '.loan', '.work', '.cam', '.monster', '.ru',
  '.vip', '.icu', '.buzz', '.cf', '.gq', '.tk', '.ml', '.ga', '.link',
  '.rest', '.bar', '.quest', '.beauty', '.stream', '.gdn', '.racing'
];

const BRAND_TARGETS = [
  { name: 'State Bank of India (SBI)', pattern: /(sbi|onlinesbi)/i, official: ['onlinesbi.sbi', 'sbi.co.in'] },
  { name: 'HDFC Bank', pattern: /(hdfc|hdfcbank)/i, official: ['hdfcbank.com'] },
  { name: 'ICICI Bank', pattern: /(icici|icicibank)/i, official: ['icicibank.com'] },
  { name: 'Axis Bank', pattern: /(axis|axisbank)/i, official: ['axisbank.com'] },
  { name: 'Punjab National Bank (PNB)', pattern: /(pnb|pnbindia)/i, official: ['pnbindia.in'] },
  { name: 'Kotak Mahindra Bank', pattern: /(kotak)/i, official: ['kotak.com'] },
  { name: 'Paytm', pattern: /(paytm)/i, official: ['paytm.com'] },
  { name: 'PhonePe', pattern: /(phonepe)/i, official: ['phonepe.com'] },
  { name: 'Google Pay', pattern: /(gpay|googlepay)/i, official: ['pay.google.com'] },
  { name: 'PayPal', pattern: /(paypal)/i, official: ['paypal.com'] },
  { name: 'Binance', pattern: /(binance)/i, official: ['binance.com'] },
  { name: 'Coinbase', pattern: /(coinbase)/i, official: ['coinbase.com'] },
  { name: 'RBI (Reserve Bank of India)', pattern: /(rbi|sachet)/i, official: ['rbi.org.in', 'sachet.rbi.org.in'] },
  { name: 'Income Tax Dept', pattern: /(incometax|incometaxindia)/i, official: ['incometax.gov.in'] },
  { name: 'UIDAI (Aadhaar)', pattern: /(uidai|myaadhaar)/i, official: ['uidai.gov.in'] },
  { name: 'Amazon', pattern: /(amazon)/i, official: ['amazon.in', 'amazon.com'] },
];

const URL_SHORTENERS = [
  'bit.ly', 'tinyurl.com', 't.co', 'cutt.ly', 'is.gd', 'rb.gy', 'shorturl.at', 'ow.ly', 'goo.gl', 't.me'
];

const SENSITIVE_KEYWORDS = [
  'login', 'signin', 'verify', 'verification', 'kyc', 'update-pan', 'update-account',
  'pan-card', 'free-gift', 'claim-reward', 'bonus', 'reactivate', 'unblock', 'security-check',
  'apk', 'download-app', 'netbanking', 'wallet', 'crypto-airdrop', 'double-money'
];

/**
 * Analyzes URL using heuristic indicators
 * @param {string} rawUrl - URL string to examine
 * @returns {object} Analysis findings, score, and structural breakdown
 */
export function analyzeUrl(rawUrl) {
  if (!rawUrl || !rawUrl.trim()) {
    return {
      isValid: false,
      error: 'Please enter a website URL.',
      score: 0,
      riskLevel: 'LOW',
      indicators: [],
      breakdown: null,
    };
  }

  let formattedUrl = rawUrl.trim();
  // If user enters without protocol, default to https:// for URL parsing
  if (!/^https?:\/\//i.test(formattedUrl)) {
    formattedUrl = 'http://' + formattedUrl;
  }

  let parsedUrl;
  try {
    parsedUrl = new URL(formattedUrl);
  } catch (err) {
    return {
      isValid: false,
      error: 'Invalid URL format. Please check the website address.',
      score: 0,
      riskLevel: 'LOW',
      indicators: [],
      breakdown: null,
    };
  }

  const hostname = parsedUrl.hostname.toLowerCase();
  const protocol = parsedUrl.protocol;
  const pathname = parsedUrl.pathname;
  const search = parsedUrl.search;
  const port = parsedUrl.port;
  const fullPath = pathname + search;

  const indicators = [];
  let score = 0;

  // 1. Check for IP-based Hostname
  const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
  const isIpBased = ipv4Regex.test(hostname) || hostname.startsWith('[') || hostname.endsWith(']');
  if (isIpBased) {
    score += 40;
    indicators.push({
      type: 'IP_HOST',
      severity: 'critical',
      titleEn: 'IP-Based Website Host (No Domain Name)',
      titleHi: 'IP-आधारित वेबसाइट होस्ट (कोई डोमेन नाम नहीं)',
      descEn: 'The URL uses a raw IP address instead of a registered domain name. Legitimate banking and fintech services always use verified corporate domain names.',
      descHi: 'URL पंजीकृत डोमेन के बजाय एक कच्चा IP पता उपयोग करता है। वास्तविक बैंक हमेशा पंजीकृत डोमेन का उपयोग करते हैं।',
    });
  }

  // 2. Check Protocol (HTTP vs HTTPS)
  const isInsecureHttp = protocol === 'http:';
  if (isInsecureHttp) {
    score += 25;
    indicators.push({
      type: 'INSECURE_HTTP',
      severity: 'high',
      titleEn: 'Unencrypted Connection (Insecure HTTP)',
      titleHi: 'असुरक्षित गैर-एन्क्रिप्टेड कनेक्शन (HTTP)',
      descEn: 'The website does not use SSL/TLS encryption (HTTPS). Any sensitive passwords, card numbers, or personal data entered here can be intercepted in transit.',
      descHi: 'वेबसाइट सुरक्षित एन्क्रिप्शन (HTTPS) का उपयोग नहीं करती है। इसमें दर्ज किया गया डेटा आसानी से चोरी हो सकता है।',
    });
  }

  // 3. Check Suspicious TLDs
  const matchedTld = SUSPICIOUS_TLDS.find((tld) => hostname.endsWith(tld));
  if (matchedTld) {
    score += 30;
    indicators.push({
      type: 'SUSPICIOUS_TLD',
      severity: 'high',
      titleEn: `High-Risk Top-Level Domain (${matchedTld})`,
      titleHi: `उच्च जोखिम वाला डोमेन एक्सटेंशन (${matchedTld})`,
      descEn: `The domain extension '${matchedTld}' is frequently used by short-lived scam sites and phishing portals due to low-cost or anonymous registrations.`,
      descHi: `'${matchedTld}' एक्सटेंशन का उपयोग साइबर अपराधी अक्सर थोड़े समय के लिए फर्जी साइटें बनाने में करते हैं।`,
    });
  }

  // 4. Check Brand Typosquatting / Impersonation
  let brandSpoofed = null;
  BRAND_TARGETS.forEach((brand) => {
    if (brand.pattern.test(hostname)) {
      // Check if hostname matches any official domain
      const isOfficial = brand.official.some((off) => hostname === off || hostname.endsWith('.' + off));
      if (!isOfficial) {
        brandSpoofed = brand;
        score += 45;
        indicators.push({
          type: 'BRAND_IMPERSONATION',
          severity: 'critical',
          titleEn: `Potential Brand Impersonation: ${brand.name}`,
          titleHi: `संभावित ब्रांड स्पूफिंग: ${brand.name}`,
          descEn: `The domain mentions '${brand.name}' brand keywords but does NOT match the official domains (${brand.official.join(', ')}). This is a strong indicator of a phishing clone.`,
          descHi: `डोमेन '${brand.name}' के नाम का उपयोग करता है लेकिन आधिकारिक पते (${brand.official.join(', ')}) से मेल नहीं खाता। यह फ़िशिंग साइट का बड़ा संकेत है।`,
        });
      }
    }
  });

  // 5. Check URL Shorteners
  const isShortener = URL_SHORTENERS.some((shortener) => hostname === shortener || hostname.endsWith('.' + shortener));
  if (isShortener) {
    score += 20;
    indicators.push({
      type: 'URL_SHORTENER',
      severity: 'medium',
      titleEn: 'Obfuscated Link (URL Shortener)',
      titleHi: 'छुपाया गया लिंक (URL शॉर्टनर)',
      descEn: 'The link is wrapped inside a URL shortener service which hides the true destination server. Phishers use this to bypass automated security filters.',
      descHi: 'यह लिंक असली पते को छुपाता है। धोखेबाज सुरक्षा जांच से बचने के लिए शॉर्ट लिंक का उपयोग करते हैं।',
    });
  }

  // 6. Check Deceptive Nested Subdomains
  const hostParts = hostname.split('.');
  if (hostParts.length >= 4 && !isIpBased) {
    score += 20;
    indicators.push({
      type: 'EXCESSIVE_SUBDOMAINS',
      severity: 'medium',
      titleEn: 'Excessive Subdomain Nesting',
      titleHi: 'अत्यधिक सबडोमेन लेयरिंग',
      descEn: 'The URL uses multiple subdomain levels (e.g., sbi.bank.verify.xyz), which is often configured to deceive mobile users who cannot see the full domain name.',
      descHi: 'यह URL कई सबडोमेन का उपयोग करता है, जिससे मोबाइल उपयोगकर्ताओं को धोखा दिया जा सके।',
    });
  }

  // 7. Check Sensitive Keywords in Path
  const detectedKeywords = SENSITIVE_KEYWORDS.filter((kw) => fullPath.toLowerCase().includes(kw));
  if (detectedKeywords.length > 0 && (isInsecureHttp || matchedTld || brandSpoofed || isIpBased)) {
    score += 15;
    indicators.push({
      type: 'SENSITIVE_PATH',
      severity: 'medium',
      titleEn: `High-Risk Action Keywords in Path (${detectedKeywords.slice(0, 3).join(', ')})`,
      titleHi: `पाथ में उच्च जोखिम वाले कीवर्ड (${detectedKeywords.slice(0, 3).join(', ')})`,
      descEn: 'The URL path contains authentication or action keywords combined with other warning signs, suggesting credential harvesting or malicious downloads.',
      descHi: 'URL में लॉगिन या प्रमाणीकरण से जुड़े शब्द हैं जो क्रेडेंशियल्स चुराने का संकेत देते हैं।',
    });
  }

  // 8. Punycode check
  if (hostname.includes('xn--')) {
    score += 35;
    indicators.push({
      type: 'PUNYCODE_HOMOGRAPH',
      severity: 'high',
      titleEn: 'Punycode / Homograph Character Encoding (xn--)',
      titleHi: 'पूनीकोड / भ्रामक वर्ण एन्कोडिंग (xn--)',
      descEn: 'Contains Internationalized Domain Name (IDN) Punycode characters designed to visually mimic legitimate Latin letters while leading to a different server.',
      descHi: 'यह डोमेन देखने में असली अक्षरों जैसा लगता है लेकिन पूनीकोड का उपयोग करके अलग सर्वर पर ले जाता है।',
    });
  }

  // Cap score
  const finalScore = Math.min(100, Math.max(0, score));
  let riskLevel = 'LOW';
  if (finalScore >= 50) riskLevel = 'HIGH';
  else if (finalScore >= 20) riskLevel = 'MEDIUM';

  // Extract TLD
  const tld = hostParts.length > 1 ? '.' + hostParts[hostParts.length - 1] : 'N/A';

  return {
    isValid: true,
    rawUrl,
    formattedUrl,
    score: finalScore,
    riskLevel,
    indicators,
    breakdown: {
      protocol: protocol.replace(':', '').toUpperCase(),
      hostname,
      tld,
      path: fullPath || '/',
      isHttps: protocol === 'https:',
      isIpBased,
      port: port || (protocol === 'https:' ? '443' : '80'),
    },
    safetyRecommendations: [
      {
        en: 'Never enter bank passwords, credit card PINs, or OTPs on websites flagged with warnings.',
        hi: 'चेतावनी वाली वेबसाइटों पर कभी भी बैंक पासवर्ड, क्रेडिट कार्ड पिन या OTP दर्ज न करें।',
      },
      {
        en: 'Inspect the exact domain name: look for misspellings, hyphenated brand names, and unfamiliar extensions.',
        hi: 'डोमेन नाम की वर्तनी ध्यान से देखें: गलत स्पेलिंग और संदिग्ध एक्सटेंशन से सावधान रहें।',
      },
      {
        en: 'For banking services, always bookmark the official bank site or use their verified mobile application.',
        hi: 'बैंकिंग सेवाओं के लिए हमेशा आधिकारिक वेबसाइट बुकमार्क करें या उनके सत्यापित ऐप का उपयोग करें।',
      },
    ],
  };
}

// Preset URL scenarios for testing
export const SAMPLE_URLS = [
  {
    id: 'sample-url-phish-xyz',
    labelEn: 'Phishing Bank Clone (.xyz)',
    labelHi: 'फर्जी बैंक क्लोन (.xyz)',
    riskLevel: 'HIGH',
    url: 'http://sbi-secure-kyc-update-portal.xyz/login.php?user_id=verify',
  },
  {
    id: 'sample-url-ip',
    labelEn: 'IP-based Insecure Link',
    labelHi: 'IP-आधारित असुरक्षित लिंक',
    riskLevel: 'HIGH',
    url: 'http://192.168.44.12/secure-gateway/pay-invoice.php',
  },
  {
    id: 'sample-url-crypto-top',
    labelEn: 'High-Yield Crypto Scheme (.top)',
    labelHi: 'उच्च रिटर्न क्रिप्टो लिंक (.top)',
    riskLevel: 'HIGH',
    url: 'https://double-bitcoin-guaranteed-24h.top/invest/deposit',
  },
  {
    id: 'sample-url-shortener',
    labelEn: 'Obfuscated Shortened Link',
    labelHi: 'छोटा किया गया लिंक (Shortener)',
    riskLevel: 'MEDIUM',
    url: 'http://bit.ly/claim-free-prize-money-now',
  },
  {
    id: 'sample-url-subdomain',
    labelEn: 'Misleading Subdomain Spoof',
    labelHi: 'भ्रामक सबडोमेन लिंक',
    riskLevel: 'HIGH',
    url: 'https://paypal.com-security-check.work/verify-credentials',
  },
  {
    id: 'sample-url-safe',
    labelEn: 'Official Bank Portal (Safe)',
    labelHi: 'आधिकारिक बैंक पोर्टल (सुरक्षित)',
    riskLevel: 'LOW',
    url: 'https://www.onlinesbi.sbi/portal/index.html',
  },
];
