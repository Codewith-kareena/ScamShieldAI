import React, { useState } from 'react';
import {
  FileCheck,
  Sparkles,
  Trash2,
  Copy,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  ShieldAlert,
  HelpCircle,
  Scale,
  TrendingUp,
  Percent,
  Check,
  X,
  Lock,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useSession } from '../../context/SessionContext';
import { analyzeClaim, SAMPLE_CLAIMS } from '../../utils/claimAnalyzer';
import RiskBadge from '../common/RiskBadge';
import ScoreGauge from '../common/ScoreGauge';
import LoadingScanner from '../common/LoadingScanner';

export default function ClaimChecker() {
  const { lang, t } = useLanguage();
  const { recordAnalysis, showToast } = useSession();

  const [inputClaim, setInputClaim] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [result, setResult] = useState(null);
  const [copied, setCopied] = useState(false);

  // Analyze Claim
  const handleAnalyze = () => {
    if (!inputClaim.trim()) {
      showToast(
        lang === 'hi'
          ? 'कृपया सत्यापन के लिए कोई वित्तीय दावा या विज्ञापन दर्ज करें।'
          : 'Please enter a financial claim or advertisement to verify.',
        'error'
      );
      return;
    }

    setIsScanning(true);
    setResult(null);

    setTimeout(() => {
      const analysis = analyzeClaim(inputClaim);
      setResult(analysis);
      setIsScanning(false);

      // Record to Session Dashboard
      recordAnalysis({
        type: 'claim',
        title: lang === 'hi' ? 'वित्तीय दावा व स्कीम मूल्यांकन' : 'Financial Claim & Scheme Evaluation',
        preview: inputClaim,
        riskLevel: analysis.riskLevel,
        score: analysis.score,
        categoriesCount: {
          unrealistic_returns: analysis.findings.filter((f) => f.category === 'UNREALISTIC_YIELD').length,
          ponzi_mlm: analysis.findings.filter((f) => f.category === 'PONZI_MLM').length,
        },
        indicatorsCount: analysis.findings.length,
        fullData: analysis,
      });

      showToast(
        lang === 'hi'
          ? `दावा मूल्यांकन पूर्ण: ${analysis.riskLevel} जोखिम स्तर`
          : `Claim audit complete: ${analysis.riskLevel} risk tier`,
        analysis.riskLevel === 'HIGH' ? 'danger' : analysis.riskLevel === 'MEDIUM' ? 'info' : 'success'
      );
    }, 1000);
  };

  // Load sample claim
  const handleLoadSample = (sample) => {
    setInputClaim(sample.text);
    setResult(null);
    showToast(
      lang === 'hi'
        ? `नमूना दावा लोड किया गया: ${sample.labelHi}`
        : `Sample claim loaded: ${sample.labelEn}`,
      'info'
    );
  };

  // Clear input
  const handleClear = () => {
    setInputClaim('');
    setResult(null);
  };

  // Copy report
  const handleCopyReport = () => {
    if (!result) return;
    const findingsList = result.findings
      .map(
        (f) =>
          `• [${f.category}] ${lang === 'hi' ? f.titleHi : f.titleEn}: ${
            lang === 'hi' ? f.descHi : f.descEn
          }`
      )
      .join('\n');

    const checklist = result.missingComplianceChecklist
      .map((c) => `• [${c.status.toUpperCase()}] ${lang === 'hi' ? c.itemHi : c.itemEn}`)
      .join('\n');

    const report = `=== ScamShield AI Financial Claim Assessment ===
Tagline: "Think Before You Trust."
Risk Level: ${result.riskLevel} (${result.score}/100)

Evaluated Claim Text:
"${inputClaim}"

Detected Warning Signs:
${findingsList || 'None (Standard compliance indicators detected)'}

Regulatory Compliance & Missing Evidence Checklist:
${checklist}

Important Non-Advisory Notice:
ScamShield AI is an educational tool and does NOT provide financial, investment, buy, sell, or hold recommendations.
=================================================`;

    navigator.clipboard.writeText(report);
    setCopied(true);
    showToast(t('messageScanner.copiedToast'), 'success');
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14 animate-in fade-in duration-300">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-10 space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-extrabold uppercase tracking-wider border border-emerald-200">
          <FileCheck size={13} />
          <span>{lang === 'hi' ? 'निवेश और पोंजी हीयूरिस्टिक्स' : 'Investment & Scheme Heuristic Engine'}</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#173B65] tracking-tight">
          {t('claimChecker.title')}
        </h1>
        <p className="text-sm text-slate-600 font-medium">
          {t('claimChecker.subtitle')}
        </p>
      </div>

      {/* Input Box Card */}
      <div className="card-premium p-6 md:p-8 bg-white border-slate-200 shadow-lg relative">
        <div className="flex items-center justify-between mb-3">
          <label className="text-xs font-bold text-[#173B65] uppercase tracking-wider flex items-center gap-1.5">
            <span>{t('claimChecker.inputLabel')}</span>
          </label>
          {inputClaim && (
            <button
              onClick={handleClear}
              className="text-rose-600 hover:text-rose-800 flex items-center gap-1 px-2.5 py-1 rounded-md bg-rose-50 hover:bg-rose-100 font-semibold transition-colors text-xs cursor-pointer"
            >
              <Trash2 size={13} />
              <span>{t('claimChecker.clearBtn')}</span>
            </button>
          )}
        </div>

        {/* Textarea */}
        <div className="relative">
          <textarea
            value={inputClaim}
            onChange={(e) => {
              setInputClaim(e.target.value);
              if (result) setResult(null);
            }}
            placeholder={t('claimChecker.inputPlaceholder')}
            rows={4}
            className="w-full p-4 rounded-xl border border-slate-200 focus:border-[#16B8C4] focus:ring-3 focus:ring-cyan-100 outline-none text-slate-800 text-sm leading-relaxed transition-all placeholder:text-slate-400 bg-slate-50/50"
          />
        </div>

        {/* Action Button & Disclaimer Alert */}
        <div className="mt-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <Scale size={14} className="text-emerald-600 shrink-0" />
            <span>
              {lang === 'hi'
                ? 'शैक्षणिक सत्यापन उपकरण। कोई खरीद या बिक्री की सलाह नहीं दी जाती।'
                : 'Educational verification only. Never provides investment buy/sell advice.'}
            </span>
          </div>

          <button
            onClick={handleAnalyze}
            disabled={isScanning || !inputClaim.trim()}
            className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-[#173B65] to-[#16B8C4] hover:from-[#122E4F] hover:to-[#0F959F] text-white rounded-xl font-extrabold text-sm shadow-md hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
          >
            <Sparkles size={16} className={isScanning ? 'animate-spin' : ''} />
            <span>
              {isScanning ? t('claimChecker.analysingBtn') : t('claimChecker.analyseBtn')}
            </span>
          </button>
        </div>

        {/* Preset Sample Selector */}
        <div className="mt-7 pt-6 border-t border-slate-100">
          <p className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
            <HelpCircle size={13} className="text-cyan-600" />
            <span>{t('claimChecker.samplePrompt')}</span>
          </p>
          <div className="flex flex-wrap gap-2">
            {SAMPLE_CLAIMS.map((sample) => (
              <button
                key={sample.id}
                onClick={() => handleLoadSample(sample)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-cyan-50 hover:text-[#173B65] border border-slate-200 hover:border-cyan-300 text-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    sample.riskLevel === 'HIGH' ? 'bg-rose-500' : 'bg-emerald-500'
                  }`}
                />
                <span>{lang === 'hi' ? sample.labelHi : sample.labelEn}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Loading Animation */}
      {isScanning && <LoadingScanner type="claim" />}

      {/* Analysis Results Display */}
      {result && result.isValid && (
        <div className="mt-8 space-y-6 animate-in fade-in slide-in-from-bottom-3 duration-400">
          {/* Main Assessment Score Card */}
          <div className="card-premium p-6 md:p-8 bg-white border-slate-200 shadow-xl">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-6 border-b border-slate-100">
              <div className="flex items-center gap-5">
                <ScoreGauge score={result.score} riskLevel={result.riskLevel} />
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <RiskBadge level={result.riskLevel} size="md" />
                  </div>
                  <h3 className="text-xl font-extrabold text-[#173B65]">
                    {t('claimChecker.resultsTitle')}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    {result.findings.length > 0
                      ? lang === 'hi'
                        ? `${result.findings.length} अवास्तविक या पोंजी स्कीम चेतावनी संकेत पाए गए।`
                        : `${result.findings.length} unrealistic or Ponzi scheme red flags identified.`
                      : lang === 'hi'
                      ? 'दावे में मानक सेबी/म्यूचुअल फंड जोखिम प्रकटीकरण पाया गया।'
                      : 'Claim contains standard market risk disclosures and regulated parameters.'}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={handleCopyReport}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-[#173B65] border border-slate-200 rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  {copied ? <CheckCircle2 size={14} className="text-emerald-600" /> : <Copy size={14} />}
                  <span>{copied ? t('common.copied') : t('claimChecker.copyReportBtn')}</span>
                </button>
              </div>
            </div>

            {/* MANDATORY NON-ADVISORY DISCLAIMER */}
            <div className="mt-6 p-4 rounded-xl bg-blue-50 border border-blue-200 flex items-start gap-3">
              <Scale size={18} className="text-blue-700 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-extrabold text-blue-900 uppercase tracking-wider mb-1">
                  {t('claimChecker.disclaimerTitle')}
                </h4>
                <p className="text-xs text-blue-800 leading-relaxed">
                  {t('claimChecker.disclaimer')}
                </p>
              </div>
            </div>

            {/* Benchmark Yield Reality Check */}
            {result.benchmarkComparison && (
              <div className="mt-6 space-y-3">
                <h4 className="text-xs font-bold text-[#173B65] uppercase tracking-wider flex items-center gap-1.5">
                  <TrendingUp size={14} className="text-[#16B8C4]" />
                  <span>{lang === 'hi' ? 'बाजार बेंचमार्क रिटर्न तुलना' : 'Market Economic Benchmark Comparison'}</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
                    <span className="text-[10px] uppercase font-bold text-slate-400">
                      {lang === 'hi' ? 'आरबीआई रेपो दर (जोखिम-मुक्त)' : 'RBI Repo Rate (Risk-Free)'}
                    </span>
                    <p className="text-base font-extrabold text-slate-800 mt-1">
                      {result.benchmarkComparison.rbiRepoRate}
                    </p>
                  </div>
                  <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
                    <span className="text-[10px] uppercase font-bold text-slate-400">
                      {lang === 'hi' ? 'सुरक्षित बैंक FD दर' : 'Safe Bank FD Benchmark'}
                    </span>
                    <p className="text-base font-extrabold text-slate-800 mt-1">
                      {result.benchmarkComparison.bankFdRate}
                    </p>
                  </div>
                  <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
                    <span className="text-[10px] uppercase font-bold text-slate-400">
                      {lang === 'hi' ? 'शेयर बाजार इक्विटी औसत' : 'Broad Market Equities (Nifty)'}
                    </span>
                    <p className="text-base font-extrabold text-slate-800 mt-1">
                      {result.benchmarkComparison.equityMarketAvg}
                    </p>
                  </div>
                </div>
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700">
                  <strong>{lang === 'hi' ? 'आर्थिक निष्कर्ष: ' : 'Economic Assessment: '}</strong>
                  <span>
                    {lang === 'hi'
                      ? result.benchmarkComparison.claimedSchemeAssessmentHi
                      : result.benchmarkComparison.claimedSchemeAssessment}
                  </span>
                </div>
              </div>
            )}

            {/* Detected Red Flag Findings */}
            {result.findings.length > 0 && (
              <div className="mt-8 space-y-3">
                <h4 className="text-xs font-bold text-[#173B65] uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldAlert size={14} className="text-rose-600" />
                  <span>{t('claimChecker.explanationTitle')} ({result.findings.length})</span>
                </h4>
                <div className="space-y-3">
                  {result.findings.map((f, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-slate-50 transition-colors space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-[#173B65]">
                          {lang === 'hi' ? f.titleHi : f.titleEn}
                        </span>
                        <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-md bg-rose-100 text-rose-800">
                          {f.severity}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        {lang === 'hi' ? f.descHi : f.descEn}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Regulatory Compliance & Missing Evidence Checklist */}
            <div className="mt-8 space-y-3">
              <h4 className="text-xs font-bold text-[#173B65] uppercase tracking-wider flex items-center gap-1.5">
                <FileCheck size={14} className="text-[#16B8C4]" />
                <span>{t('claimChecker.missingChecklistTitle')}</span>
              </h4>
              <div className="space-y-2">
                {result.missingComplianceChecklist.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 flex items-start justify-between gap-3 text-xs"
                  >
                    <div className="space-y-0.5">
                      <p className="font-bold text-slate-800">
                        {lang === 'hi' ? item.itemHi : item.itemEn}
                      </p>
                      <p className="text-slate-500">
                        {lang === 'hi' ? item.descHi : item.descEn}
                      </p>
                    </div>
                    <span
                      className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase shrink-0 flex items-center gap-1 ${
                        item.status === 'verified'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-rose-100 text-rose-800 border border-rose-300'
                      }`}
                    >
                      {item.status === 'verified' ? (
                        <>
                          <Check size={12} />
                          <span>{lang === 'hi' ? 'मौजूद' : 'Found'}</span>
                        </>
                      ) : (
                        <>
                          <X size={12} />
                          <span>{lang === 'hi' ? 'गायब / अनुपस्थित' : 'Missing'}</span>
                        </>
                      )}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Verification Steps */}
            <div className="mt-8 pt-6 border-t border-slate-100 space-y-3">
              <h4 className="text-xs font-bold text-[#173B65] uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck size={14} className="text-emerald-600" />
                <span>{t('claimChecker.verificationStepsTitle')}</span>
              </h4>
              <div className="space-y-2.5">
                {result.verificationSteps.map((step, i) => (
                  <div
                    key={i}
                    className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 space-y-1"
                  >
                    <p className="font-bold text-[#173B65]">
                      {i + 1}. {lang === 'hi' ? step.stepHi : step.stepEn}
                    </p>
                    <p className="text-slate-600 leading-relaxed">
                      {lang === 'hi' ? step.detailHi : step.detailEn}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
