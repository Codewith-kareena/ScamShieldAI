import React, { useState } from 'react';
import {
  MessageSquare,
  Sparkles,
  Trash2,
  Copy,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  ClipboardPaste,
  ShieldAlert,
  HelpCircle,
  Share2,
  Lock,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useSession } from '../../context/SessionContext';
import { analyzeMessage, SAMPLE_MESSAGES } from '../../utils/messageAnalyzer';
import RiskBadge from '../common/RiskBadge';
import ScoreGauge from '../common/ScoreGauge';
import HighlightedText from '../common/HighlightedText';
import LoadingScanner from '../common/LoadingScanner';

export default function MessageScanner() {
  const { lang, t } = useLanguage();
  const { recordAnalysis, showToast } = useSession();

  const [inputText, setInputText] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [result, setResult] = useState(null);
  const [copied, setCopied] = useState(false);

  // Handle analysis
  const handleAnalyze = () => {
    if (!inputText.trim()) {
      showToast(
        lang === 'hi'
          ? 'कृपया विश्लेषण के लिए कोई संदेश दर्ज करें या नमूना चुनें।'
          : 'Please enter a message to analyze or select a sample.',
        'error'
      );
      return;
    }

    setIsScanning(true);
    setResult(null);

    // Multi-phase scanner delay for realistic UX
    setTimeout(() => {
      const analysis = analyzeMessage(inputText);
      setResult(analysis);
      setIsScanning(false);

      // Record to Session Dashboard
      recordAnalysis({
        type: 'message',
        title: lang === 'hi' ? 'संदेश हीयूरिस्टिक विश्लेषण' : 'Message Heuristic Analysis',
        preview: inputText,
        riskLevel: analysis.riskLevel,
        score: analysis.score,
        categoriesCount: analysis.categoriesCount,
        indicatorsCount: analysis.findings.length,
        fullData: analysis,
      });

      showToast(
        lang === 'hi'
          ? `संदेश विश्लेषण पूर्ण: ${analysis.riskLevel} जोखिम स्तर`
          : `Message scan complete: ${analysis.riskLevel} risk tier`,
        analysis.riskLevel === 'HIGH' ? 'danger' : analysis.riskLevel === 'MEDIUM' ? 'info' : 'success'
      );
    }, 1100);
  };

  // Load a sample message
  const handleLoadSample = (sample) => {
    setInputText(sample.text);
    setResult(null);
    showToast(
      lang === 'hi'
        ? `नमूना लोड किया गया: ${sample.labelHi}`
        : `Sample loaded: ${sample.labelEn}`,
      'info'
    );
  };

  // Paste from clipboard helper
  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setInputText(text);
        showToast(lang === 'hi' ? 'क्लिपबोर्ड से टेक्स्ट पेस्ट किया गया!' : 'Pasted from clipboard!', 'info');
      }
    } catch (e) {
      showToast(lang === 'hi' ? 'क्लिपबोर्ड एक्सेस विफल रहा।' : 'Clipboard access denied.', 'error');
    }
  };

  // Clear input
  const handleClear = () => {
    setInputText('');
    setResult(null);
  };

  // Copy structured report to clipboard
  const handleCopyReport = () => {
    if (!result) return;
    const findingsList = result.findings
      .map(
        (f) =>
          `• [${f.category}] ${lang === 'hi' ? f.titleHi : f.titleEn}: ${
            lang === 'hi' ? f.descHi : f.descEn
          }`
      )
      .join('\n');

    const recsList = result.recommendations
      .map((r) => `• ${lang === 'hi' ? r.hi : r.en}`)
      .join('\n');

    const report = `=== ScamShield AI Analysis Report ===
Tagline: "Think Before You Trust."
Risk Level: ${result.riskLevel} (${result.score}/100)
Message Length: ${result.textLength} characters

Original Message:
"${inputText}"

Detected Threat Indicators:
${findingsList || 'None (Safe markers found)'}

Safety Recommendations:
${recsList}
======================================`;

    navigator.clipboard.writeText(report);
    setCopied(true);
    showToast(t('messageScanner.copiedToast'), 'success');
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14 animate-in fade-in duration-300">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-10 space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-blue-50 text-blue-800 text-xs font-extrabold uppercase tracking-wider border border-blue-200">
          <MessageSquare size={13} />
          <span>{lang === 'hi' ? 'टेक्स्ट और SMS हीयूरिस्टिक्स' : 'Text & SMS Heuristic Engine'}</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#173B65] tracking-tight">
          {t('messageScanner.title')}
        </h1>
        <p className="text-sm text-slate-600 font-medium">
          {t('messageScanner.subtitle')}
        </p>
      </div>

      {/* Input Box Card */}
      <div className="card-premium p-6 md:p-8 bg-white border-slate-200 shadow-lg relative">
        <div className="flex items-center justify-between mb-3">
          <label className="text-xs font-bold text-[#173B65] uppercase tracking-wider flex items-center gap-1.5">
            <span>{t('messageScanner.inputLabel')}</span>
          </label>
          <div className="flex items-center gap-2 text-xs">
            <button
              onClick={handlePaste}
              className="text-slate-600 hover:text-[#173B65] flex items-center gap-1 px-2.5 py-1 rounded-md bg-slate-100 hover:bg-slate-200 font-semibold transition-colors cursor-pointer"
              title="Paste from clipboard"
            >
              <ClipboardPaste size={13} />
              <span>{lang === 'hi' ? 'पेस्ट करें' : 'Paste'}</span>
            </button>
            {inputText && (
              <button
                onClick={handleClear}
                className="text-rose-600 hover:text-rose-800 flex items-center gap-1 px-2.5 py-1 rounded-md bg-rose-50 hover:bg-rose-100 font-semibold transition-colors cursor-pointer"
                title="Clear input"
              >
                <Trash2 size={13} />
                <span>{t('messageScanner.clearBtn')}</span>
              </button>
            )}
          </div>
        </div>

        {/* Textarea */}
        <div className="relative">
          <textarea
            value={inputText}
            onChange={(e) => {
              setInputText(e.target.value);
              if (result) setResult(null);
            }}
            placeholder={t('messageScanner.inputPlaceholder')}
            rows={5}
            className="w-full p-4 rounded-xl border border-slate-200 focus:border-[#16B8C4] focus:ring-3 focus:ring-cyan-100 outline-none text-slate-800 text-sm leading-relaxed transition-all placeholder:text-slate-400 bg-slate-50/50"
          />
          <div className="absolute bottom-3 right-3 text-[11px] font-mono text-slate-400 pointer-events-none">
            {inputText.length} {lang === 'hi' ? 'वर्ण' : 'characters'}
          </div>
        </div>

        {/* Action Button & Privacy Reminder */}
        <div className="mt-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <Lock size={14} className="text-emerald-600 shrink-0" />
            <span>{t('messageScanner.privacyNotice')}</span>
          </div>

          <button
            onClick={handleAnalyze}
            disabled={isScanning || !inputText.trim()}
            className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-[#173B65] to-[#16B8C4] hover:from-[#122E4F] hover:to-[#0F959F] text-white rounded-xl font-extrabold text-sm shadow-md hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
          >
            <Sparkles size={16} className={isScanning ? 'animate-spin' : ''} />
            <span>
              {isScanning
                ? t('messageScanner.analysingBtn')
                : t('messageScanner.analyseBtn')}
            </span>
          </button>
        </div>

        {/* Preset Sample Selector */}
        <div className="mt-7 pt-6 border-t border-slate-100">
          <p className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
            <HelpCircle size={13} className="text-cyan-600" />
            <span>{t('messageScanner.samplePrompt')}</span>
          </p>
          <div className="flex flex-wrap gap-2">
            {SAMPLE_MESSAGES.map((sample) => (
              <button
                key={sample.id}
                onClick={() => handleLoadSample(sample)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-cyan-50 hover:text-[#173B65] border border-slate-200 hover:border-cyan-300 text-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    sample.riskLevel === 'HIGH' ? 'bg-rose-500' : 'bg-emerald-500'
                  }`}
                />
                <span>{lang === 'hi' ? sample.labelHi : sample.labelEn}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Loading Animation */}
      {isScanning && <LoadingScanner type="message" />}

      {/* Analysis Results Display */}
      {result && (
        <div className="mt-8 space-y-6 animate-in fade-in slide-in-from-bottom-3 duration-400">
          {/* Main Assessment Score Card */}
          <div className="card-premium p-6 md:p-8 bg-white border-slate-200 shadow-xl">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-6 border-b border-slate-100">
              <div className="flex items-center gap-5">
                <ScoreGauge score={result.score} riskLevel={result.riskLevel} />
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <RiskBadge level={result.riskLevel} size="md" />
                  </div>
                  <h3 className="text-xl font-extrabold text-[#173B65]">
                    {t('messageScanner.resultsTitle')}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    {result.findings.length > 0
                      ? lang === 'hi'
                        ? `${result.findings.length} संभावित चेतावनी संकेतक पहचाने गए।`
                        : `${result.findings.length} threat indicators flagged by heuristic engine.`
                      : lang === 'hi'
                      ? 'कोई दुर्भावनापूर्ण पैटर्न नहीं मिला। सुरक्षित लेन-देन अलर्ट प्रतीत होता है।'
                      : 'No malicious heuristic patterns found. Appears consistent with normal alerts.'}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={handleCopyReport}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-[#173B65] border border-slate-200 rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  {copied ? <CheckCircle2 size={14} className="text-emerald-600" /> : <Copy size={14} />}
                  <span>{copied ? t('common.copied') : t('messageScanner.copyReportBtn')}</span>
                </button>
              </div>
            </div>

            {/* Highlighted Message Area */}
            <div className="mt-6 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-[#173B65] uppercase tracking-wider">
                  {t('messageScanner.highlightedTitle')}
                </h4>
                <span className="text-[11px] text-slate-500 font-medium">
                  {t('messageScanner.highlightedHelp')}
                </span>
              </div>
              <HighlightedText text={inputText} matchedTokens={result.matchedTokens} />
            </div>

            {/* Detected Categories List */}
            {result.findings.length > 0 && (
              <div className="mt-8 space-y-3">
                <h4 className="text-xs font-bold text-[#173B65] uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldAlert size={14} className="text-rose-600" />
                  <span>{t('messageScanner.detectedCategories')} ({result.findings.length})</span>
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {result.findings.map((f, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-slate-50 transition-colors space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-[#173B65]">
                          {lang === 'hi' ? f.titleHi : f.titleEn}
                        </span>
                        <span
                          className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-md ${
                            f.severity === 'critical'
                              ? 'bg-rose-100 text-rose-800'
                              : f.severity === 'high'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}
                        >
                          {f.severity}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        {lang === 'hi' ? f.descHi : f.descEn}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Safety Recommendations */}
            <div className="mt-8 pt-6 border-t border-slate-100 space-y-3">
              <h4 className="text-xs font-bold text-[#173B65] uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck size={14} className="text-emerald-600" />
                <span>{t('messageScanner.recommendationsTitle')}</span>
              </h4>
              <div className="space-y-2">
                {result.recommendations.map((rec, i) => (
                  <div
                    key={i}
                    className="flex items-start gap-2.5 p-3 rounded-xl bg-emerald-50/60 border border-emerald-100 text-xs text-slate-700 font-medium"
                  >
                    <CheckCircle2 size={15} className="text-emerald-600 shrink-0 mt-0.5" />
                    <span>{lang === 'hi' ? rec.hi : rec.en}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
