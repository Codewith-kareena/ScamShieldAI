import React, { useState } from 'react';
import {
  Globe,
  Sparkles,
  Trash2,
  Copy,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  ShieldAlert,
  HelpCircle,
  ExternalLink,
  Lock,
  Unlock,
  Server,
  FileCode,
  Info,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useSession } from '../../context/SessionContext';
import { analyzeUrl, SAMPLE_URLS } from '../../utils/urlAnalyzer';
import RiskBadge from '../common/RiskBadge';
import ScoreGauge from '../common/ScoreGauge';
import LoadingScanner from '../common/LoadingScanner';

export default function UrlChecker() {
  const { lang, t } = useLanguage();
  const { recordAnalysis, showToast } = useSession();

  const [inputUrl, setInputUrl] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [result, setResult] = useState(null);
  const [copied, setCopied] = useState(false);

  // Analyze URL
  const handleAnalyze = () => {
    if (!inputUrl.trim()) {
      showToast(
        lang === 'hi'
          ? 'कृपया जांचने के लिए कोई वेबसाइट URL दर्ज करें।'
          : 'Please enter a website URL to inspect.',
        'error'
      );
      return;
    }

    setIsScanning(true);
    setResult(null);

    setTimeout(() => {
      const analysis = analyzeUrl(inputUrl);
      setResult(analysis);
      setIsScanning(false);

      if (!analysis.isValid) {
        showToast(analysis.error, 'error');
        return;
      }

      // Record to Session Dashboard
      recordAnalysis({
        type: 'url',
        title: lang === 'hi' ? 'URL संरचना हीयूरिस्टिक जांच' : 'URL Structural Inspection',
        preview: inputUrl,
        riskLevel: analysis.riskLevel,
        score: analysis.score,
        categoriesCount: {
          malicious_links: analysis.indicators.length,
          insecure_url: analysis.breakdown?.isHttps ? 0 : 1,
        },
        indicatorsCount: analysis.indicators.length,
        fullData: analysis,
      });

      showToast(
        lang === 'hi'
          ? `URL जांच पूर्ण: ${analysis.riskLevel} जोखिम स्तर`
          : `URL check complete: ${analysis.riskLevel} risk tier`,
        analysis.riskLevel === 'HIGH' ? 'danger' : analysis.riskLevel === 'MEDIUM' ? 'info' : 'success'
      );
    }, 1000);
  };

  // Load sample URL
  const handleLoadSample = (sample) => {
    setInputUrl(sample.url);
    setResult(null);
    showToast(
      lang === 'hi' ? `नमूना URL लोड किया गया: ${sample.labelHi}` : `Sample URL loaded: ${sample.labelEn}`,
      'info'
    );
  };

  // Clear input
  const handleClear = () => {
    setInputUrl('');
    setResult(null);
  };

  // Copy report
  const handleCopyReport = () => {
    if (!result) return;
    const indicatorsList = result.indicators
      .map(
        (ind) =>
          `• [${ind.severity.toUpperCase()}] ${lang === 'hi' ? ind.titleHi : ind.titleEn}: ${
            lang === 'hi' ? ind.descHi : ind.descEn
          }`
      )
      .join('\n');

    const report = `=== ScamShield AI URL Preliminary Assessment ===
Tagline: "Think Before You Trust."
Risk Level: ${result.riskLevel} (${result.score}/100)
Tested URL: ${result.formattedUrl}
Protocol: ${result.breakdown?.protocol}
Host Domain: ${result.breakdown?.hostname}
Top-Level Domain (TLD): ${result.breakdown?.tld}

Detected Heuristic Indicators:
${indicatorsList || 'No suspicious structural indicators flagged'}

Important Notice:
This is a preliminary heuristic evaluation of domain syntax and infrastructure. It cannot guarantee absolute safety. Always verify directly through verified official channels.
=================================================`;

    navigator.clipboard.writeText(report);
    setCopied(true);
    showToast(t('messageScanner.copiedToast'), 'success');
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14 animate-in fade-in duration-300">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-10 space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-cyan-50 text-cyan-800 text-xs font-extrabold uppercase tracking-wider border border-cyan-200">
          <Globe size={13} />
          <span>{lang === 'hi' ? 'डोमेन और लिंक हीयूरिस्टिक्स' : 'Domain & Link Heuristic Engine'}</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#173B65] tracking-tight">
          {t('urlChecker.title')}
        </h1>
        <p className="text-sm text-slate-600 font-medium">
          {t('urlChecker.subtitle')}
        </p>
      </div>

      {/* Input Box Card */}
      <div className="card-premium p-6 md:p-8 bg-white border-slate-200 shadow-lg relative">
        <div className="flex items-center justify-between mb-3">
          <label className="text-xs font-bold text-[#173B65] uppercase tracking-wider flex items-center gap-1.5">
            <span>{t('urlChecker.inputLabel')}</span>
          </label>
          {inputUrl && (
            <button
              onClick={handleClear}
              className="text-rose-600 hover:text-rose-800 flex items-center gap-1 px-2.5 py-1 rounded-md bg-rose-50 hover:bg-rose-100 font-semibold transition-colors text-xs cursor-pointer"
            >
              <Trash2 size={13} />
              <span>{t('urlChecker.clearBtn')}</span>
            </button>
          )}
        </div>

        {/* URL Input */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Globe size={18} />
          </div>
          <input
            type="text"
            value={inputUrl}
            onChange={(e) => {
              setInputUrl(e.target.value);
              if (result) setResult(null);
            }}
            placeholder={t('urlChecker.inputPlaceholder')}
            className="w-full pl-10 pr-4 py-3.5 rounded-xl border border-slate-200 focus:border-[#16B8C4] focus:ring-3 focus:ring-cyan-100 outline-none text-slate-800 text-sm leading-relaxed transition-all placeholder:text-slate-400 bg-slate-50/50"
          />
        </div>

        {/* Action Button */}
        <div className="mt-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <Info size={14} className="text-cyan-600 shrink-0" />
            <span>
              {lang === 'hi'
                ? 'प्रोटोकॉल (http/https) न डालने पर सिस्टम स्वतः जांच करेगा।'
                : 'Supports both standard URLs and domain names with auto-protocol resolution.'}
            </span>
          </div>

          <button
            onClick={handleAnalyze}
            disabled={isScanning || !inputUrl.trim()}
            className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-[#173B65] to-[#16B8C4] hover:from-[#122E4F] hover:to-[#0F959F] text-white rounded-xl font-extrabold text-sm shadow-md hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
          >
            <Sparkles size={16} className={isScanning ? 'animate-spin' : ''} />
            <span>
              {isScanning ? t('urlChecker.analysingBtn') : t('urlChecker.analyseBtn')}
            </span>
          </button>
        </div>

        {/* Preset Sample Selector */}
        <div className="mt-7 pt-6 border-t border-slate-100">
          <p className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
            <HelpCircle size={13} className="text-cyan-600" />
            <span>{t('urlChecker.samplePrompt')}</span>
          </p>
          <div className="flex flex-wrap gap-2">
            {SAMPLE_URLS.map((sample) => (
              <button
                key={sample.id}
                onClick={() => handleLoadSample(sample)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-cyan-50 hover:text-[#173B65] border border-slate-200 hover:border-cyan-300 text-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    sample.riskLevel === 'HIGH' ? 'bg-rose-500' : 'bg-emerald-500'
                  }`}
                />
                <span>{lang === 'hi' ? sample.labelHi : sample.labelEn}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Loading Animation */}
      {isScanning && <LoadingScanner type="url" />}

      {/* Analysis Results Display */}
      {result && result.isValid && (
        <div className="mt-8 space-y-6 animate-in fade-in slide-in-from-bottom-3 duration-400">
          {/* Main Assessment Score Card */}
          <div className="card-premium p-6 md:p-8 bg-white border-slate-200 shadow-xl">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-6 border-b border-slate-100">
              <div className="flex items-center gap-5">
                <ScoreGauge score={result.score} riskLevel={result.riskLevel} />
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <RiskBadge level={result.riskLevel} size="md" />
                  </div>
                  <h3 className="text-xl font-extrabold text-[#173B65]">
                    {t('urlChecker.resultsTitle')}
                  </h3>
                  <p className="text-xs text-slate-500 font-mono mt-1 break-all">
                    {result.formattedUrl}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={handleCopyReport}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-[#173B65] border border-slate-200 rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  {copied ? <CheckCircle2 size={14} className="text-emerald-600" /> : <Copy size={14} />}
                  <span>{copied ? t('common.copied') : t('urlChecker.copyReportBtn')}</span>
                </button>
              </div>
            </div>

            {/* MANDATORY PRELIMINARY ASSESSMENT DISCLAIMER */}
            <div className="mt-6 p-4 rounded-xl bg-amber-50 border border-amber-200 flex items-start gap-3">
              <AlertTriangle size={18} className="text-amber-700 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-extrabold text-amber-900 uppercase tracking-wider mb-1">
                  {t('urlChecker.preliminaryDisclaimerTitle')}
                </h4>
                <p className="text-xs text-amber-800 leading-relaxed">
                  {t('urlChecker.preliminaryDisclaimer')}
                </p>
              </div>
            </div>

            {/* Structural Breakdown Grid */}
            {result.breakdown && (
              <div className="mt-6 space-y-2">
                <h4 className="text-xs font-bold text-[#173B65] uppercase tracking-wider">
                  {t('urlChecker.domainBreakdown')}
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <span className="text-[10px] uppercase font-bold text-slate-400">
                      {t('urlChecker.protocol')}
                    </span>
                    <div className="flex items-center gap-1.5 font-bold text-slate-800">
                      {result.breakdown.isHttps ? (
                        <Lock size={13} className="text-emerald-600" />
                      ) : (
                        <Unlock size={13} className="text-rose-600" />
                      )}
                      <span>{result.breakdown.protocol}</span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <span className="text-[10px] uppercase font-bold text-slate-400">
                      {t('urlChecker.tld')}
                    </span>
                    <p className="font-bold text-slate-800 font-mono">
                      {result.breakdown.tld}
                    </p>
                  </div>

                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <span className="text-[10px] uppercase font-bold text-slate-400">
                      {lang === 'hi' ? 'होस्ट प्रकार' : 'Host Type'}
                    </span>
                    <p className="font-bold text-slate-800">
                      {result.breakdown.isIpBased
                        ? lang === 'hi'
                          ? 'कच्चा IP एड्रेस'
                          : 'Raw IP Host'
                        : lang === 'hi'
                        ? 'पंजीकृत डोमेन'
                        : 'Named Domain'}
                    </p>
                  </div>

                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <span className="text-[10px] uppercase font-bold text-slate-400">
                      {t('urlChecker.hostname')}
                    </span>
                    <p className="font-bold text-slate-800 font-mono truncate" title={result.breakdown.hostname}>
                      {result.breakdown.hostname}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Detected Indicators */}
            {result.indicators.length > 0 ? (
              <div className="mt-8 space-y-3">
                <h4 className="text-xs font-bold text-[#173B65] uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldAlert size={14} className="text-rose-600" />
                  <span>{t('urlChecker.detectedWarnings')} ({result.indicators.length})</span>
                </h4>
                <div className="space-y-3">
                  {result.indicators.map((ind, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-slate-50 transition-colors space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-[#173B65]">
                          {lang === 'hi' ? ind.titleHi : ind.titleEn}
                        </span>
                        <span
                          className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-md ${
                            ind.severity === 'critical'
                              ? 'bg-rose-100 text-rose-800'
                              : ind.severity === 'high'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}
                        >
                          {ind.severity}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        {lang === 'hi' ? ind.descHi : ind.descEn}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="mt-8 p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-3">
                <CheckCircle2 size={20} className="text-emerald-600 shrink-0" />
                <p className="text-xs text-emerald-800 font-medium leading-relaxed">
                  {lang === 'hi'
                    ? 'कोई स्पष्ट हीयूरिस्टिक खतरा (असुरक्षित HTTP, संदिग्ध TLD, या IP होस्ट) नहीं मिला। कृपया आधिकारिक स्रोतों से डोमेन की सत्यता अवश्य जांचें।'
                    : 'No standard heuristic red flags (Insecure HTTP, suspicious TLDs, or IP hostnames) detected. Standard web hygiene still applies.'}
                </p>
              </div>
            )}

            {/* Safe Browsing Suggestions */}
            <div className="mt-8 pt-6 border-t border-slate-100 space-y-3">
              <h4 className="text-xs font-bold text-[#173B65] uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck size={14} className="text-emerald-600" />
                <span>{t('urlChecker.safetyTipsTitle')}</span>
              </h4>
              <div className="space-y-2">
                {result.safetyRecommendations.map((tip, i) => (
                  <div
                    key={i}
                    className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 font-medium"
                  >
                    <CheckCircle2 size={15} className="text-cyan-600 shrink-0 mt-0.5" />
                    <span>{lang === 'hi' ? tip.hi : tip.en}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
