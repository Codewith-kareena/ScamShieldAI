import React from 'react';
import { Shield, Lock, Cpu, Eye, CheckCircle2, Heart, Award, Sparkles } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export default function AboutView({ onOpenEmergency }) {
  const { lang, t } = useLanguage();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14 space-y-10 animate-in fade-in duration-300">
      {/* Brand & Mission Banner */}
      <div className="card-premium p-8 md:p-10 bg-gradient-to-br from-white via-cyan-50/20 to-white border-cyan-200 shadow-xl text-center space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#173B65] to-[#16B8C4] flex items-center justify-center text-white mx-auto shadow-md">
          <Shield size={36} />
        </div>
        <div className="space-y-1">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-[#173B65] tracking-tight">
            ScamShield <span className="text-[#16B8C4]">AI</span>
          </h1>
          <p className="text-sm font-extrabold text-cyan-800 tracking-wider uppercase">
            {lang === 'hi' ? '“विश्वास करने से पहले सोचें”' : '“Think Before You Trust.”'}
          </p>
        </div>
        <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mx-auto leading-relaxed">
          {t('about.missionDesc')}
        </p>
      </div>

      {/* 2 Core Pillars: Transparent Heuristics + Privacy by Design */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Transparent Heuristics */}
        <div className="card-premium p-6 bg-white border-slate-200 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
              <Cpu size={20} />
            </div>
            <h3 className="text-base font-extrabold text-[#173B65]">
              {t('about.transparencyTitle')}
            </h3>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            {t('about.transparencyDesc')}
          </p>
          <div className="space-y-2 pt-2 text-xs text-slate-700">
            <div className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-[#16B8C4]" />
              <span>{lang === 'hi' ? 'कोई भ्रामक AI भ्रम (Hallucination) नहीं' : 'No opaque black-box hallucinations'}</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-[#16B8C4]" />
              <span>{lang === 'hi' ? 'स्पष्ट और सत्यापित सुरक्षा नियम' : 'Deterministic & explainable rule logic'}</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-[#16B8C4]" />
              <span>{lang === 'hi' ? 'हाइलाइट किए गए साक्ष्य और कारण' : 'Exact token highlights & risk weights'}</span>
            </div>
          </div>
        </div>

        {/* Privacy by Design */}
        <div className="card-premium p-6 bg-white border-slate-200 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <Lock size={20} />
            </div>
            <h3 className="text-base font-extrabold text-[#173B65]">
              {t('about.privacyTitle')}
            </h3>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            {lang === 'hi'
              ? 'आपकी व्यक्तिगत और वित्तीय जानकारी की सुरक्षा हमारी सर्वोच्च प्राथमिकता है।'
              : 'Our architecture is built from the ground up to ensure zero sensitive exposure.'}
          </p>
          <div className="space-y-2 pt-2 text-xs text-slate-700">
            <div className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-emerald-600" />
              <span>{lang === 'hi' ? 'ब्राउज़र में स्थानीय निष्पादन' : '100% Client-Side In-Browser execution'}</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-emerald-600" />
              <span>{lang === 'hi' ? 'संदेशों का शून्य सर्वर संग्रह' : 'Zero remote database or text logging'}</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-emerald-600" />
              <span>{lang === 'hi' ? 'केवल गैर-संवेदनशील सत्र मेट्रिक्स' : 'Non-identifiable session counters only'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Light Theme Design Principles */}
      <div className="card-premium p-6 bg-slate-50 border-slate-200 space-y-3">
        <h3 className="text-xs font-bold text-[#173B65] uppercase tracking-wider flex items-center gap-2">
          <Sparkles size={14} className="text-[#16B8C4]" />
          <span>{lang === 'hi' ? 'डिजाइन दर्शन: केवल लाइट थीम' : 'Design Philosophy: Pure Light Theme'}</span>
        </h3>
        <p className="text-xs text-slate-600 leading-relaxed">
          {lang === 'hi'
            ? 'ScamShield AI को स्वच्छ सफेद पृष्ठभूमि (#FFFFFF), नेवी ब्लू (#173B65) और सियान (#16B8C4) के साथ एक पेशेवर फिनटेक/SaaS डैशबोर्ड के रूप में तैयार किया गया है।'
            : 'ScamShield AI is engineered exclusively with a crisp, light fintech visual aesthetic. Utilizing clean white foundations (#FFFFFF), authoritative navy (#173B65), high-visibility cyan (#16B8C4), and soft neutral cards, it ensures optimal clarity, readability, and trustworthiness across all devices.'}
        </p>
      </div>
    </div>
  );
}
