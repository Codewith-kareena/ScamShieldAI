import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  HelpCircle,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Trophy,
  Award,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

const QUIZ_QUESTIONS = [
  {
    id: 1,
    questionEn: 'You receive an SMS: "Dear Customer, your electricity will be disconnected at 9:30 PM tonight due to unpaid bill. Call officer at 98765XXXXX immediately." What should you do?',
    questionHi: 'आपको एक SMS मिलता है: "प्रिय ग्राहक, आज रात 9:30 बजे बिल न भरने के कारण आपकी बिजली काट दी जाएगी। तुरंत अधिकारी 98765XXXXX पर कॉल करें।" आपको क्या करना चाहिए?',
    optionsEn: [
      'Call the phone number in the SMS immediately to clear the bill.',
      'Ignore the SMS number; check official electricity board app/bill or official toll-free helpline.',
      'Send UPI money to the sender number to avoid power disconnection.',
      'Download the helper APK app they send on WhatsApp.',
    ],
    optionsHi: [
      'बिल का भुगतान करने के लिए SMS में दिए गए नंबर पर तुरंत कॉल करें।',
      'SMS नंबर को नजरअंदाज करें; बिजली विभाग के आधिकारिक ऐप या हेल्पलाइन पर जांचें।',
      'बिजली कटने से बचने के लिए प्रेषक के नंबर पर UPI से पैसे भेजें।',
      'व्हाट्सएप पर भेजी गई सहायक APK ऐप डाउनलोड करें।',
    ],
    correctIndex: 1,
    explanationEn: 'Electricity boards NEVER threaten same-night disconnection via personal mobile numbers or APK links. Always verify directly through the official state discom portal.',
    explanationHi: 'बिजली विभाग कभी भी व्यक्तिगत मोबाइल नंबर या APK लिंक से बिजली काटने की धमकी नहीं देते। हमेशा आधिकारिक पोर्टल से जांचें।',
  },
  {
    id: 2,
    questionEn: 'An investment bot on Telegram promises "15% daily guaranteed return with zero risk" and asks for ₹10,000 via crypto USDT. Is this safe?',
    questionHi: 'टेलीग्राम पर एक बॉट "बिना जोखिम के 15% दैनिक गारंटीड रिटर्न" का वादा करता है और USDT क्रिप्टो में ₹10,000 मांगता है। क्या यह सुरक्षित है?',
    optionsEn: [
      'Yes, AI trading bots always guarantee 100% risk-free profits.',
      'Yes, but only if they show screenshots of past client withdrawals.',
      'No! Legitimate investments cannot guarantee fixed high returns without risk. It is a Ponzi fraud.',
      'Yes, because cryptocurrency transactions are completely insured by the government.',
    ],
    optionsHi: [
      'हाँ, AI ट्रेडिंग बॉट हमेशा 100% जोखिम-मुक्त मुनाफे की गारंटी देते हैं।',
      'हाँ, लेकिन केवल तभी जब वे अन्य ग्राहकों के पैसे निकालने के स्क्रीनशॉट दिखाएं।',
      'नहीं! वैध निवेश कभी बिना जोखिम के भारी रिटर्न की गारंटी नहीं दे सकते। यह पोंजी फ्रॉड है।',
      'हाँ, क्योंकि क्रिप्टोकरेंसी लेन-देन सरकार द्वारा पूरी तरह से बीमित होते हैं।',
    ],
    correctIndex: 2,
    explanationEn: '15% daily return compounds to an impossible thousands of percent annually. Guaranteed zero-risk high yields are mathematically impossible and a hallmark of Ponzi scams.',
    explanationHi: '15% दैनिक रिटर्न सालाना हजारों प्रतिशत बनता है जो असंभव है। शून्य जोखिम के साथ भारी रिटर्न पोंजी घोटाले का पक्का संकेत है।',
  },
  {
    id: 3,
    questionEn: 'A caller claiming to be a CBI Inspector tells you on a WhatsApp video call that you are under "Digital Arrest" and must transfer ₹50,000 to clear your name. How should you react?',
    questionHi: 'व्हाट्सएप वीडियो कॉल पर एक व्यक्ति खुद को सीबीआई इंस्पेक्टर बताकर कहता है कि आप "डिजिटल अरेस्ट" हैं और नाम हटाने के लिए ₹50,000 ट्रांसफर करें। आप क्या करेंगे?',
    optionsEn: [
      'Immediately transfer the money to avoid getting arrested.',
      'Stay on the video call and show them all your bank account statements.',
      'Hang up immediately! Indian law has no concept of "Digital Arrest" and police never conduct trials on video calls.',
      'Ask the caller for a 50% discount on the settlement fee.',
    ],
    optionsHi: [
      'गिरफ्तारी से बचने के लिए तुरंत पैसे ट्रांसफर कर दें।',
      'वीडियो कॉल पर बने रहें और उन्हें अपने सभी बैंक खातों का विवरण दिखाएं।',
      'तुरंत कॉल काटें! भारतीय कानून में "डिजिटल अरेस्ट" जैसा कोई प्रावधान नहीं है और पुलिस वीडियो कॉल पर जांच नहीं करती।',
      'कॉल करने वाले से समझौते के शुल्क में 50% छूट मांगें।',
    ],
    correctIndex: 2,
    explanationEn: 'The Ministry of Home Affairs and Supreme Court have repeatedly clarified that "Digital Arrest" is a complete fraud. Real police never demand money or conduct hearings over video calls.',
    explanationHi: 'गृह मंत्रालय ने स्पष्ट किया है कि "डिजिटल अरेस्ट" पूरी तरह फर्जी है। असली पुलिस कभी वीडियो कॉल पर पैसे की मांग नहीं करती।',
  },
  {
    id: 4,
    questionEn: 'While receiving money on Google Pay / PhonePe from a buyer, they ask you to enter your 6-digit UPI PIN to "accept" the payment. What happens if you enter your PIN?',
    questionHi: 'Google Pay या PhonePe पर किसी से पैसे प्राप्त करते समय, वह आपसे पैसे "स्वीकार" करने के लिए अपना 6-अंकों का UPI पिन डालने को कहता है। क्या होगा?',
    optionsEn: [
      'The money will be deposited into your bank account safely.',
      'Money will be DEDUCTED from your bank account, not received.',
      'Your bank account limits will increase.',
      'Nothing happens until you scan the buyer’s fingerprint.',
    ],
    optionsHi: [
      'पैसे सुरक्षित रूप से आपके बैंक खाते में जमा हो जाएंगे।',
      'आपके बैंक खाते से पैसे कट जाएंगे, प्राप्त नहीं होंगे।',
      'आपके बैंक खाते की सीमा बढ़ जाएगी।',
      'जब तक आप फिंगरप्रिंट स्कैन नहीं करेंगे तब तक कुछ नहीं होगा।',
    ],
    correctIndex: 1,
    explanationEn: 'GOLDEN RULE: You NEVER need to enter your UPI PIN to receive money. UPI PIN is strictly used only when SENDING/DEDUCTING money from your account.',
    explanationHi: 'सुनहरा नियम: पैसे प्राप्त करने के लिए कभी भी UPI पिन डालने की आवश्यकता नहीं होती। UPI पिन केवल पैसे भेजने के लिए होता है।',
  },
  {
    id: 5,
    questionEn: 'You see a job advertisement: "Earn ₹4,000/day by liking YouTube videos. Deposit ₹1,500 registration security fee to start." What is the true nature of this offer?',
    questionHi: 'आप एक विज्ञापन देखते हैं: "यूट्यूब वीडियो लाइक करके ₹4,000/दिन कमाएं। शुरू करने के लिए ₹1,500 सुरक्षा शुल्क जमा करें।" यह क्या है?',
    optionsEn: [
      'A legitimate digital marketing freelance opportunity.',
      'A task-based advance fee trap designed to take your deposit and demand higher prepayments.',
      'An official YouTube partnership program.',
      'A government-backed youth employment scheme.',
    ],
    optionsHi: [
      'एक वास्तविक डिजिटल मार्केटिंग फ्रीलांस अवसर।',
      'एक टास्क-आधारित फ्रॉड जो आपकी जमा राशि हड़पने और आगे और पैसे ऐंठने के लिए बनाया गया है।',
      'एक आधिकारिक यूट्यूब पार्टनरशिप प्रोग्राम।',
      'एक सरकारी युवा रोजगार योजना।',
    ],
    correctIndex: 1,
    explanationEn: 'Legitimate employers never charge employees advance "security deposits". Scammers pay small initial sums (₹100-200) to gain trust, then steal thousands in prepaid tasks.',
    explanationHi: 'वास्तविक कंपनियां नौकरी देने के लिए कभी पैसे नहीं मांगतीं। धोखेबाज विश्वास जीतने के लिए पहले छोटे पैसे देते हैं, फिर बड़ी रकम हड़प लेते हैं।',
  },
];

export default function ScamQuiz() {
  const { lang, t } = useLanguage();

  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);

  const currentQ = QUIZ_QUESTIONS[currentIdx];

  const handleSelectOption = (index) => {
    if (isAnswered) return;
    setSelectedOption(index);
    setIsAnswered(true);

    if (index === currentQ.correctIndex) {
      setScore((prev) => prev + 1);
    }
  };

  const handleNext = () => {
    if (currentIdx < QUIZ_QUESTIONS.length - 1) {
      setCurrentIdx((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setIsCompleted(true);
      // Trigger celebratory confetti burst
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (e) {
        // silent fallback
      }
    }
  };

  const handleRestart = () => {
    setCurrentIdx(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setScore(0);
    setIsCompleted(false);
  };

  return (
    <div className="card-premium p-6 md:p-8 bg-white border-slate-200 shadow-xl">
      {/* Quiz Header */}
      <div className="flex items-center justify-between pb-6 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-cyan-50 text-cyan-700 flex items-center justify-center shrink-0">
            <HelpCircle size={24} />
          </div>
          <div>
            <h3 className="text-xl font-extrabold text-[#173B65]">
              {t('knowledge.quizTitle')}
            </h3>
            <p className="text-xs text-slate-500 font-medium">
              {t('knowledge.quizDesc')}
            </p>
          </div>
        </div>

        {!isCompleted && (
          <div className="text-right">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
              {lang === 'hi' ? 'प्रश्न' : 'Question'}
            </span>
            <span className="text-lg font-extrabold text-[#173B65] font-mono">
              {currentIdx + 1} / {QUIZ_QUESTIONS.length}
            </span>
          </div>
        )}
      </div>

      {!isCompleted ? (
        <div className="mt-6 space-y-6 animate-in fade-in duration-200">
          {/* Question Text */}
          <div className="p-4.5 bg-slate-50 border border-slate-200 rounded-2xl">
            <h4 className="text-sm sm:text-base font-bold text-slate-800 leading-relaxed">
              {lang === 'hi' ? currentQ.questionHi : currentQ.questionEn}
            </h4>
          </div>

          {/* Options Grid */}
          <div className="space-y-3">
            {(lang === 'hi' ? currentQ.optionsHi : currentQ.optionsEn).map((optionText, idx) => {
              const isSelected = selectedOption === idx;
              const isCorrect = idx === currentQ.correctIndex;

              let btnStyle = 'bg-white border-slate-200 hover:border-cyan-400 hover:bg-cyan-50/40 text-slate-700';

              if (isAnswered) {
                if (isCorrect) {
                  btnStyle = 'bg-emerald-50 border-emerald-400 text-emerald-900 font-bold';
                } else if (isSelected && !isCorrect) {
                  btnStyle = 'bg-rose-50 border-rose-400 text-rose-900 font-bold';
                } else {
                  btnStyle = 'bg-slate-50 border-slate-200 text-slate-400 opacity-60';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  disabled={isAnswered}
                  className={`w-full p-4 rounded-xl border text-left text-xs sm:text-sm font-medium transition-all flex items-start gap-3.5 cursor-pointer shadow-2xs ${btnStyle}`}
                >
                  <span className="w-6 h-6 rounded-full border border-current flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span className="flex-1 leading-snug">{optionText}</span>
                  {isAnswered && isCorrect && (
                    <CheckCircle2 size={18} className="text-emerald-600 shrink-0 mt-0.5" />
                  )}
                  {isAnswered && isSelected && !isCorrect && (
                    <XCircle size={18} className="text-rose-600 shrink-0 mt-0.5" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Answer Explanation & Next Action */}
          {isAnswered && (
            <div className="p-4 rounded-xl bg-cyan-50/70 border border-cyan-200 text-xs text-cyan-950 space-y-2 animate-in fade-in slide-in-from-top-1">
              <div className="flex items-center gap-1.5 font-extrabold text-cyan-900 uppercase tracking-wider text-[11px]">
                <ShieldCheck size={14} className="text-cyan-700" />
                <span>{lang === 'hi' ? 'सुरक्षा नियम स्पष्टीकरण' : 'Cyber Defense Rule'}</span>
              </div>
              <p className="leading-relaxed font-medium">
                {lang === 'hi' ? currentQ.explanationHi : currentQ.explanationEn}
              </p>
            </div>
          )}

          {/* Bottom Next Button */}
          {isAnswered && (
            <div className="flex justify-end pt-2">
              <button
                onClick={handleNext}
                className="px-6 py-3 bg-[#173B65] hover:bg-[#122E4F] text-white rounded-xl text-xs font-extrabold shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>
                  {currentIdx === QUIZ_QUESTIONS.length - 1
                    ? t('knowledge.quizFinishBtn')
                    : t('knowledge.quizNextBtn')}
                </span>
                <ArrowRight size={14} />
              </button>
            </div>
          )}
        </div>
      ) : (
        /* Quiz Completion Screen */
        <div className="text-center py-10 space-y-6 animate-in zoom-in-95 duration-300">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-br from-amber-400 to-amber-500 text-white flex items-center justify-center shadow-lg animate-bounce">
            <Trophy size={40} />
          </div>

          <div className="space-y-1">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              {t('knowledge.quizScoreLabel')}
            </span>
            <h4 className="text-4xl font-extrabold text-[#173B65]">
              {score} / {QUIZ_QUESTIONS.length}
            </h4>
            <p className="text-xs sm:text-sm font-semibold text-slate-600 mt-2">
              {score === 5
                ? lang === 'hi'
                  ? '🌟 उत्कृष्ट! आपकी साइबर सुरक्षा समझ अत्यंत मजबूत है!'
                  : '🌟 Outstanding! You possess top-tier scam detection instincts!'
                : score >= 3
                ? lang === 'hi'
                  ? '👍 बहुत अच्छा! आप अधिकांश आधुनिक घोटालों से सावधान हैं।'
                  : '👍 Well done! You are alert to most common modern scams.'
                : lang === 'hi'
                ? '⚠️ सतर्क रहें! सुरक्षा रेड फ्लैग्स गाइड को ध्यान से पढ़ें।'
                : '⚠️ Stay vigilant! Review the 5 Golden Rules below to sharpen your radar.'}
            </p>
          </div>

          <button
            onClick={handleRestart}
            className="px-6 py-3 bg-[#173B65] hover:bg-[#122E4F] text-white rounded-xl text-xs font-extrabold shadow-md transition-all inline-flex items-center gap-2 cursor-pointer"
          >
            <RotateCcw size={15} />
            <span>{t('knowledge.quizRestartBtn')}</span>
          </button>
        </div>
      )}
    </div>
  );
}
