import React from 'react';
import {
  ShieldAlert,
  Flame,
  KeyRound,
  TrendingUp,
  Download,
  Gift,
  ExternalLink,
  PhoneCall,
  Lock,
  CheckCircle2,
  AlertOctagon,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import ScamQuiz from './ScamQuiz';

export default function RedFlagsGuide({ onOpenEmergency }) {
  const { lang, t } = useLanguage();

  const rules = [
    {
      num: '01',
      icon: Flame,
      color: 'bg-rose-100 text-rose-700',
      titleEn: '1. Artificial Urgency & Panic',
      titleHi: '1. कृत्रिम घबराहट और तात्कालिकता',
      descEn:
        'Fraudsters use artificial deadlines ("account blocked in 2 hours", "electricity cut tonight", "police raid imminent") to prevent you from thinking calmly or consulting family.',
      descHi:
        'धोखेबाज आपको सोचने का समय न देने और परिवार से सलाह न लेने के लिए झूठी घबराहट ("2 घंटे में खाता बंद", "आज रात बिजली कटेगी") पैदा करते हैं।',
      defenseEn: 'DEFENSE: Always pause. Genuine institutions allow ample time for official dispute resolution.',
      defenseHi: 'उपाय: हमेशा रुकें। वास्तविक बैंक और सरकारी विभाग हमेशा आधिकारिक प्रक्रिया के लिए पर्याप्त समय देते हैं।',
    },
    {
      num: '02',
      icon: KeyRound,
      color: 'bg-amber-100 text-amber-700',
      titleEn: '2. Demands for Secret Credentials',
      titleHi: '2. गुप्त क्रेडेंशियल्स की मांग',
      descEn:
        'No bank employee, police officer, or tax official will EVER request your OTP, UPI PIN, password, or CVV number. Sharing these gives attackers complete access to empty your accounts.',
      descHi:
        'कोई भी बैंक कर्मचारी या पुलिस अधिकारी कभी भी कॉल या संदेश पर आपका OTP, UPI पिन या CVV नहीं मांगता। इन्हें साझा करने पर खाता खाली हो सकता है।',
      defenseEn: 'DEFENSE: Never share OTP or enter your UPI PIN while receiving money from anyone.',
      defenseHi: 'उपाय: कभी भी OTP साझा न करें और पैसे प्राप्त करते समय कभी UPI पिन दर्ज न करें।',
    },
    {
      num: '03',
      icon: TrendingUp,
      color: 'bg-blue-100 text-blue-700',
      titleEn: '3. "Guaranteed" High Yields & Zero Risk',
      titleHi: '3. "गारंटीड" उच्च रिटर्न और शून्य जोखिम',
      descEn:
        'High return with zero risk violates basic financial economics. Schemes promising double money in days or 15% daily returns are mathematically impossible Ponzi structures.',
      descHi:
        'बिना जोखिम के भारी रिटर्न वित्तीय अर्थशास्त्र के नियमों के खिलाफ है। कुछ दिनों में पैसे दोगुने करने के वादे पोंजी घोटाले होते हैं।',
      defenseEn: 'DEFENSE: Cross-check the advisor registration on sebi.gov.in and check sachet.rbi.org.in.',
      defenseHi: 'उपाय: sebi.gov.in और sachet.rbi.org.in पर हमेशा लाइसेंस और पंजीकरण की पुष्टि करें।',
    },
    {
      num: '04',
      icon: Download,
      color: 'bg-purple-100 text-purple-700',
      titleEn: '4. WhatsApp APK Files & Screen Sharing',
      titleHi: '4. व्हाट्सएप APK फाइलें और स्क्रीन शेयरिंग',
      descEn:
        'Never install `.apk` files sent over messaging apps or download remote-access apps (AnyDesk, TeamViewer) at the request of callers pretending to "help" you update banking KYC.',
      descHi:
        'व्हाट्सएप पर भेजी गई APK फाइलें या किसी अनजान के कहने पर AnyDesk/TeamViewer कभी इंस्टॉल न करें। यह आपके फोन का नियंत्रण चुरा लेते हैं।',
      defenseEn: 'DEFENSE: Only install verified apps directly from official Google Play Store or Apple App Store.',
      defenseHi: 'उपाय: केवल आधिकारिक Google Play Store या Apple App Store से ही सत्यापित ऐप इंस्टॉल करें।',
    },
    {
      num: '05',
      icon: Gift,
      color: 'bg-emerald-100 text-emerald-700',
      titleEn: '5. Upfront Advance Fees for Prizes or Jobs',
      titleHi: '5. पुरस्कार या नौकरी के लिए अग्रिम शुल्क',
      descEn:
        'Legitimate employers never demand "security deposits" to work from home, and legitimate lottery organizers never demand "advance GST/processing fees" to release winnings.',
      descHi:
        'वास्तविक नियोक्ता कभी काम शुरू करने के लिए "सिक्योरिटी डिपॉजिट" नहीं मांगते, और वास्तविक लॉटरी कभी पहले "टैक्स या फीस" नहीं मांगती।',
      defenseEn: 'DEFENSE: If you have to pay money to get money, it is 100% a fraud.',
      defenseHi: 'उपाय: यदि पैसे पाने के लिए पहले पैसे देने पड़ें, तो वह शत-प्रतिशत धोखाधड़ी है।',
    },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14 space-y-12 animate-in fade-in duration-300">
      {/* Interactive Quiz Section */}
      <ScamQuiz />

      {/* 5 Golden Rules Header */}
      <div className="text-center max-w-3xl mx-auto space-y-2 pt-6">
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-cyan-50 text-cyan-800 text-xs font-extrabold uppercase tracking-wider border border-cyan-200">
          <ShieldAlert size={13} />
          <span>{lang === 'hi' ? 'साइबर साक्षरता एवं सुरक्षा' : 'Cyber Literacy Defense Framework'}</span>
        </div>
        <h2 className="text-3xl font-extrabold text-[#173B65] tracking-tight">
          {t('knowledge.redFlagsTitle')}
        </h2>
        <p className="text-sm text-slate-500 font-medium">
          {lang === 'hi'
            ? 'वित्तीय धोखाधड़ी से बचने के लिए याद रखने योग्य 5 मौलिक सुरक्षा सिद्धांत।'
            : 'Master these five foundational principles to stay immune against sophisticated cyber fraud.'}
        </p>
      </div>

      {/* Rules Cards */}
      <div className="space-y-4">
        {rules.map((r, i) => {
          const Icon = r.icon;
          return (
            <div
              key={i}
              className="card-premium p-6 bg-white border-slate-200 flex flex-col md:flex-row items-start gap-5 hover:border-cyan-300 transition-all"
            >
              <div
                className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${r.color} font-extrabold text-sm shadow-xs`}
              >
                <Icon size={24} />
              </div>
              <div className="space-y-2 flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-extrabold text-[#173B65]">
                    {lang === 'hi' ? r.titleHi : r.titleEn}
                  </h3>
                  <span className="text-xs font-mono font-extrabold text-slate-300">
                    RULE #{r.num}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {lang === 'hi' ? r.descHi : r.descEn}
                </p>
                <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs text-emerald-900 font-semibold flex items-center gap-2">
                  <CheckCircle2 size={15} className="text-emerald-600 shrink-0" />
                  <span>{lang === 'hi' ? r.defenseHi : r.defenseEn}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Official Emergency Contact Directory Card */}
      <div className="card-premium p-6 md:p-8 bg-gradient-to-r from-slate-900 via-[#173B65] to-slate-900 text-white rounded-2xl shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-cyan-300 bg-cyan-900/60 px-2.5 py-1 rounded-md">
              {lang === 'hi' ? 'आधिकारिक सरकारी संपर्क' : 'Official Emergency Infrastructure (India)'}
            </span>
            <h3 className="text-2xl font-extrabold mt-2 text-white">
              {lang === 'hi' ? 'राष्ट्रीय आपातकालीन साइबर निर्देशिका' : 'National Cyber Crime Support Directory'}
            </h3>
          </div>
          <button
            onClick={onOpenEmergency}
            className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-1.5 shrink-0"
          >
            <PhoneCall size={15} />
            <span>{lang === 'hi' ? '1930 हेल्पलाइन विवरण' : 'Open Emergency Dialog'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div className="p-4 bg-white/10 rounded-xl border border-white/10 space-y-1">
            <span className="text-[10px] uppercase font-bold text-cyan-300">
              Cyber Helpline
            </span>
            <p className="text-xl font-extrabold text-white">1930</p>
            <p className="text-[11px] text-slate-300">24x7 Toll-Free Immediate Help</p>
          </div>

          <div className="p-4 bg-white/10 rounded-xl border border-white/10 space-y-1">
            <span className="text-[10px] uppercase font-bold text-cyan-300">
              Incident Portal
            </span>
            <a
              href="https://cybercrime.gov.in"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm font-bold text-white flex items-center gap-1 hover:underline"
            >
              cybercrime.gov.in
              <ExternalLink size={12} />
            </a>
            <p className="text-[11px] text-slate-300">File Formal Written FIR</p>
          </div>

          <div className="p-4 bg-white/10 rounded-xl border border-white/10 space-y-1">
            <span className="text-[10px] uppercase font-bold text-cyan-300">
              RBI Sachet
            </span>
            <a
              href="https://sachet.rbi.org.in"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm font-bold text-white flex items-center gap-1 hover:underline"
            >
              sachet.rbi.org.in
              <ExternalLink size={12} />
            </a>
            <p className="text-[11px] text-slate-300">Report Unauthorized Entities</p>
          </div>

          <div className="p-4 bg-white/10 rounded-xl border border-white/10 space-y-1">
            <span className="text-[10px] uppercase font-bold text-cyan-300">
              SEBI SCORES
            </span>
            <a
              href="https://scores.gov.in"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm font-bold text-white flex items-center gap-1 hover:underline"
            >
              scores.gov.in
              <ExternalLink size={12} />
            </a>
            <p className="text-[11px] text-slate-300">Investor Grievance Redressal</p>
          </div>
        </div>
      </div>
    </div>
  );
}
