import React, { useState } from 'react';
import {
  LayoutDashboard,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Activity,
  RotateCcw,
  Sparkles,
  Database,
  BarChart3,
  PieChart,
  Clock,
  Eye,
  MessageSquare,
  Globe,
  FileCheck,
  Filter,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useSession } from '../../context/SessionContext';
import RiskBadge from '../common/RiskBadge';
import HistoryDetailModal from './HistoryDetailModal';

export default function AnalyticsDashboard({ setActiveTab }) {
  const { lang, t } = useLanguage();
  const { stats, history, resetSession, loadBenchmarkData } = useSession();

  const [selectedEntry, setSelectedEntry] = useState(null);
  const [filterType, setFilterType] = useState('ALL');

  // Filter history
  const filteredHistory = history.filter((item) => {
    if (filterType === 'ALL') return true;
    return item.type.toUpperCase() === filterType;
  });

  // Category chart items
  const categoryLabels = {
    urgency_panic: { en: 'Urgency & Fear', hi: 'घबराहट / भय' },
    credential_theft: { en: 'OTP & Credentials', hi: 'OTP व पासवर्ड' },
    malicious_links: { en: 'Fake Links / APK', hi: 'संदिग्ध लिंक / APK' },
    impersonation: { en: 'Authority Impersonation', hi: 'अधिकारी का भेष' },
    unrealistic_returns: { en: 'Guaranteed Returns', hi: 'गारंटीड रिटर्न' },
    task_advance_fee: { en: 'Advance Fee & Tasks', hi: 'टास्क / अग्रिम शुल्क' },
    insecure_url: { en: 'Insecure HTTP / IP', hi: 'असुरक्षित HTTP / IP' },
    ponzi_mlm: { en: 'Ponzi / MLM Mechanics', hi: 'पोंजी / MLM योजना' },
  };

  const totalThreatsDetected = Object.values(stats.categories).reduce((a, b) => a + b, 0);

  // Calculate percentage of high, medium, low
  const totalScans = stats.totalScans || 0;
  const highPercent = totalScans > 0 ? Math.round((stats.highRisk / totalScans) * 100) : 0;
  const medPercent = totalScans > 0 ? Math.round((stats.mediumRisk / totalScans) * 100) : 0;
  const lowPercent = totalScans > 0 ? Math.round((stats.lowRisk / totalScans) * 100) : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14 animate-in fade-in duration-300">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-50 text-cyan-800 text-xs font-extrabold uppercase tracking-wider border border-cyan-200">
              <Activity size={13} />
              <span>{lang === 'hi' ? 'लाइव सत्र एनालिटिक्स' : 'Live Session Intelligence'}</span>
            </div>
            {stats.isBenchmarkLoaded && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 text-xs font-bold border border-amber-200">
                <Database size={12} />
                <span>{lang === 'hi' ? 'डेमो बेंचमार्क मोड' : 'Demo Benchmark Dataset'}</span>
              </span>
            )}
          </div>
          <h1 className="text-3xl font-extrabold text-[#173B65] tracking-tight">
            {t('dashboard.title')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            {t('dashboard.subtitle')}
          </p>
        </div>

        {/* Dashboard Actions */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={loadBenchmarkData}
            className="px-3.5 py-2 rounded-xl bg-cyan-50 hover:bg-cyan-100 text-[#173B65] border border-cyan-200 text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer"
            title="Load benchmark data for testing/presentation"
          >
            <Sparkles size={14} className="text-[#16B8C4]" />
            <span>{t('dashboard.loadBenchmarkBtn')}</span>
          </button>

          <button
            onClick={resetSession}
            className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-slate-200 hover:border-rose-200 text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer"
            title="Reset active session counters"
          >
            <RotateCcw size={14} />
            <span>{t('dashboard.resetSessionBtn')}</span>
          </button>
        </div>
      </div>

      {/* 4 Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        {/* Total Analyses */}
        <div className="card-premium p-5 bg-white border-slate-200 flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {t('dashboard.totalScans')}
            </span>
            <div className="text-3xl font-extrabold text-[#173B65]">
              {stats.totalScans}
            </div>
            <p className="text-[11px] text-slate-500">
              {lang === 'hi' ? 'सक्रिय ब्राउज़र सत्र में' : 'In current session'}
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-700 flex items-center justify-center">
            <Activity size={24} />
          </div>
        </div>

        {/* High Risk Detected */}
        <div className="card-premium p-5 bg-white border-rose-200 flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-rose-600 uppercase tracking-wider">
              {t('dashboard.highRiskCount')}
            </span>
            <div className="text-3xl font-extrabold text-rose-600">
              {stats.highRisk}
            </div>
            <p className="text-[11px] text-rose-500 font-semibold">
              {highPercent}% {lang === 'hi' ? 'कुल स्कैन का' : 'of total scans'}
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-700 flex items-center justify-center">
            <ShieldAlert size={24} />
          </div>
        </div>

        {/* Medium Risk */}
        <div className="card-premium p-5 bg-white border-amber-200 flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-amber-600 uppercase tracking-wider">
              {t('dashboard.mediumRiskCount')}
            </span>
            <div className="text-3xl font-extrabold text-amber-600">
              {stats.mediumRisk}
            </div>
            <p className="text-[11px] text-amber-600 font-semibold">
              {medPercent}% {lang === 'hi' ? 'कुल स्कैन का' : 'of total scans'}
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center">
            <AlertTriangle size={24} />
          </div>
        </div>

        {/* Low / Safe Risk */}
        <div className="card-premium p-5 bg-white border-emerald-200 flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-emerald-600 uppercase tracking-wider">
              {t('dashboard.lowRiskCount')}
            </span>
            <div className="text-3xl font-extrabold text-emerald-600">
              {stats.lowRisk}
            </div>
            <p className="text-[11px] text-emerald-600 font-semibold">
              {lowPercent}% {lang === 'hi' ? 'कुल स्कैन का' : 'of total scans'}
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
            <ShieldCheck size={24} />
          </div>
        </div>
      </div>

      {/* Charts & Analytics Visuals */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        {/* Threat Categories Breakdown Bar Chart (2 Cols) */}
        <div className="card-premium p-6 lg:col-span-2 bg-white border-slate-200 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 size={18} className="text-[#16B8C4]" />
              <h3 className="text-sm font-bold text-[#173B65] uppercase tracking-wider">
                {t('dashboard.categoryChartTitle')}
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {totalThreatsDetected} {lang === 'hi' ? 'पहचाने गए खतरे' : 'Total Flags'}
            </span>
          </div>

          <div className="space-y-3.5 pt-2">
            {Object.entries(stats.categories).map(([catKey, count]) => {
              const label = lang === 'hi' ? categoryLabels[catKey]?.hi : categoryLabels[catKey]?.en;
              const maxVal = Math.max(1, ...Object.values(stats.categories));
              const fillPct = Math.round((count / maxVal) * 100);

              return (
                <div key={catKey} className="space-y-1 text-xs">
                  <div className="flex items-center justify-between text-slate-700 font-semibold">
                    <span>{label || catKey}</span>
                    <span className="font-bold text-[#173B65] font-mono">{count}</span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden flex">
                    <div
                      className="h-full bg-gradient-to-r from-[#173B65] to-[#16B8C4] rounded-full transition-all duration-700 ease-out"
                      style={{ width: `${count > 0 ? Math.max(5, fillPct) : 0}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Risk Distribution Donut / Proportions Card (1 Col) */}
        <div className="card-premium p-6 bg-white border-slate-200 space-y-4 flex flex-col justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <PieChart size={18} className="text-[#16B8C4]" />
              <h3 className="text-sm font-bold text-[#173B65] uppercase tracking-wider">
                {t('dashboard.riskDistributionTitle')}
              </h3>
            </div>
            <p className="text-xs text-slate-500">
              {lang === 'hi' ? 'सत्र में जोखिम स्तर का अनुपात' : 'Risk severity breakdown for session'}
            </p>
          </div>

          {/* Visual multi-segmented bar */}
          <div className="space-y-3 py-4">
            <div className="w-full h-6 rounded-xl overflow-hidden flex shadow-inner border border-slate-200">
              <div
                style={{ width: `${highPercent}%` }}
                className="bg-rose-500 h-full transition-all duration-500"
                title={`High Risk: ${highPercent}%`}
              />
              <div
                style={{ width: `${medPercent}%` }}
                className="bg-amber-400 h-full transition-all duration-500"
                title={`Medium Risk: ${medPercent}%`}
              />
              <div
                style={{ width: `${lowPercent}%` }}
                className="bg-emerald-500 h-full transition-all duration-500"
                title={`Low Risk: ${lowPercent}%`}
              />
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-xs pt-2">
              <div className="p-2.5 bg-rose-50 rounded-xl border border-rose-200">
                <span className="block text-[10px] font-bold text-rose-700 uppercase">High</span>
                <span className="text-base font-extrabold text-rose-700">{highPercent}%</span>
              </div>
              <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-200">
                <span className="block text-[10px] font-bold text-amber-700 uppercase">Medium</span>
                <span className="text-base font-extrabold text-amber-700">{medPercent}%</span>
              </div>
              <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-200">
                <span className="block text-[10px] font-bold text-emerald-700 uppercase">Low</span>
                <span className="text-base font-extrabold text-emerald-700">{lowPercent}%</span>
              </div>
            </div>
          </div>

          {/* Scans By Tool breakdown */}
          <div className="pt-4 border-t border-slate-100 space-y-2 text-xs">
            <p className="font-bold text-slate-700 uppercase text-[10px] tracking-wider">
              {lang === 'hi' ? 'मॉड्यूल उपयोग:' : 'Scans by Engine:'}
            </p>
            <div className="flex items-center justify-between text-slate-600">
              <span className="flex items-center gap-1.5">
                <MessageSquare size={13} className="text-blue-600" />
                Message Scanner
              </span>
              <span className="font-bold text-slate-800 font-mono">{stats.scansByType.message}</span>
            </div>
            <div className="flex items-center justify-between text-slate-600">
              <span className="flex items-center gap-1.5">
                <Globe size={13} className="text-cyan-600" />
                URL Checker
              </span>
              <span className="font-bold text-slate-800 font-mono">{stats.scansByType.url}</span>
            </div>
            <div className="flex items-center justify-between text-slate-600">
              <span className="flex items-center gap-1.5">
                <FileCheck size={13} className="text-emerald-600" />
                Claim Verifier
              </span>
              <span className="font-bold text-slate-800 font-mono">{stats.scansByType.claim}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Session History Log Table */}
      <div className="card-premium p-6 md:p-8 bg-white border-slate-200 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-[#173B65] tracking-tight">
              {t('dashboard.recentHistoryTitle')}
            </h3>
            <p className="text-xs text-slate-500">
              {lang === 'hi'
                ? 'इस सत्र में विश्लेषित किए गए आइटम (गोपनीयता के लिए केवल सारांश)'
                : 'Scans performed in current session (non-sensitive summaries only)'}
            </p>
          </div>

          {/* Type Filter Buttons */}
          <div className="flex items-center gap-1.5 text-xs">
            <Filter size={13} className="text-slate-400" />
            {['ALL', 'MESSAGE', 'URL', 'CLAIM'].map((type) => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                  filterType === type
                    ? 'bg-[#173B65] text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* History Table */}
        {filteredHistory.length > 0 ? (
          <div className="overflow-x-auto pt-2">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 uppercase font-bold text-[10px] tracking-wider">
                  <th className="py-3 px-3">{t('dashboard.tableType')}</th>
                  <th className="py-3 px-3">{t('dashboard.tableInput')}</th>
                  <th className="py-3 px-3">{t('dashboard.tableRisk')}</th>
                  <th className="py-3 px-3">{t('dashboard.tableScore')}</th>
                  <th className="py-3 px-3">{t('dashboard.tableTime')}</th>
                  <th className="py-3 px-3 text-right">{t('dashboard.tableAction')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredHistory.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3 font-extrabold text-[#173B65] uppercase">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                        {item.type}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-700 max-w-xs truncate">
                      {item.preview}
                    </td>
                    <td className="py-3 px-3">
                      <RiskBadge level={item.riskLevel} size="sm" />
                    </td>
                    <td className="py-3 px-3 font-bold text-slate-800 font-mono">
                      {item.score}/100
                    </td>
                    <td className="py-3 px-3 text-slate-500 font-mono text-[11px]">
                      {new Date(item.timestamp).toLocaleTimeString()}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => setSelectedEntry(item)}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-cyan-50 text-[#173B65] hover:text-[#16B8C4] border border-slate-200 rounded-lg font-bold text-xs transition-colors flex items-center gap-1 ml-auto cursor-pointer"
                      >
                        <Eye size={12} />
                        <span>{t('dashboard.viewBtn')}</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-12 text-center space-y-3 bg-slate-50 rounded-2xl border border-dashed border-slate-200 my-4">
            <Clock size={32} className="mx-auto text-slate-300" />
            <p className="text-xs text-slate-500 font-medium">
              {t('dashboard.noHistoryYet')}
            </p>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={() => {
                  setActiveTab('message');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-3.5 py-1.5 bg-[#173B65] text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer"
              >
                Scan a Message
              </button>
              <button
                onClick={loadBenchmarkData}
                className="px-3.5 py-1.5 bg-cyan-50 text-cyan-800 border border-cyan-200 rounded-lg text-xs font-bold cursor-pointer"
              >
                Load Demo Benchmark
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Modal for viewing past scan details */}
      {selectedEntry && (
        <HistoryDetailModal
          entry={selectedEntry}
          onClose={() => setSelectedEntry(null)}
        />
      )}
    </div>
  );
}
