import React from 'react';
import { X, ShieldAlert, CheckCircle2, Clock, FileText, Globe, MessageSquare, FileCheck } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import RiskBadge from '../common/RiskBadge';
import ScoreGauge from '../common/ScoreGauge';

export default function HistoryDetailModal({ entry, onClose }) {
  const { lang } = useLanguage();

  if (!entry) return null;

  const typeIcons = {
    message: MessageSquare,
    url: Globe,
    claim: FileCheck,
  };

  const Icon = typeIcons[entry.type] || FileText;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="card-premium max-w-2xl w-full max-h-[85vh] overflow-y-auto p-6 md:p-8 bg-white border-slate-200 shadow-2xl relative">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
        >
          <X size={20} />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3.5 mb-6">
          <div className="w-12 h-12 rounded-xl bg-cyan-50 text-cyan-700 flex items-center justify-center shrink-0">
            <Icon size={24} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <RiskBadge level={entry.riskLevel} size="sm" />
              <span className="text-xs text-slate-400 font-mono">
                {new Date(entry.timestamp).toLocaleTimeString()}
              </span>
            </div>
            <h3 className="text-lg font-extrabold text-[#173B65] mt-1">
              {entry.title}
            </h3>
          </div>
        </div>

        {/* Input summary */}
        <div className="space-y-2 mb-6">
          <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            {lang === 'hi' ? 'विश्लेषण की गई सामग्री' : 'Analyzed Content'}
          </h4>
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-slate-700 whitespace-pre-wrap leading-relaxed">
            {entry.preview}
          </div>
        </div>

        {/* Score Breakdown */}
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between mb-6">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase">
              {lang === 'hi' ? 'खतरा स्कोर' : 'Threat Score'}
            </p>
            <p className="text-2xl font-extrabold text-[#173B65]">
              {entry.score} <span className="text-xs text-slate-400 font-normal">/ 100</span>
            </p>
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase">
              {lang === 'hi' ? 'पहचाने गए चेतावनी तत्व' : 'Flagged Indicators'}
            </p>
            <p className="text-2xl font-extrabold text-[#173B65]">
              {entry.indicatorsCount || 0}
            </p>
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase">
              {lang === 'hi' ? 'प्रकार' : 'Category'}
            </p>
            <p className="text-sm font-extrabold text-[#16B8C4] uppercase">
              {entry.type}
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-[#173B65] text-white hover:bg-[#122E4F] rounded-xl font-bold text-xs transition-colors"
        >
          {lang === 'hi' ? 'बंद करें' : 'Close Details'}
        </button>
      </div>
    </div>
  );
}
