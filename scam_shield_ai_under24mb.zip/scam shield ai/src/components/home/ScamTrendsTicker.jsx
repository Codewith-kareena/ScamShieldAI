import React from 'react';
import { AlertCircle, Flame } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export default function ScamTrendsTicker() {
  const { lang, t } = useLanguage();

  const tickerItems = [
    lang === 'hi'
      ? '🚨 जरूरी: फर्जी बिजली बिल डिस्कनेक्शन SMS में APK लिंक से बचें।'
      : '🚨 URGENT: Fake Electricity Bill disconnection SMS with APK links circulating.',
    lang === 'hi'
      ? '⚠️ चेतावनी: आधार OTP मांगने वाले बैंक KYC अपडेट के फर्जी संदेशों से सावधान रहें।'
      : '⚠️ WARNING: Impersonation of Bank KYC updates asking for Aadhaar OTP.',
    lang === 'hi'
      ? '🚨 अलर्ट: व्हाट्सएप पर यूट्यूब वीडियो लाइक करने के नाम पर पैसे ऐंठने वाले टास्क फ्रॉड।'
      : '🚨 ALERT: WhatsApp part-time YouTube rating jobs demanding security deposits.',
    lang === 'hi'
      ? '⚠️ सावधानी: "500% साप्ताहिक क्रिप्टो रिटर्न" वाले टेलीग्राम बॉट पोंजी ट्रैप हैं।'
      : '⚠️ CAUTION: High-yield "500% Weekly Crypto Doubler" Telegram bots flagged as Ponzi traps.',
    lang === 'hi'
      ? '🚨 एडवाइजरी: तत्काल पैसे ट्रांसफर करने की धमकी देने वाले डिजिटल अरेस्ट वीडियो कॉल से बचें।'
      : '🚨 ADVISORY: Fake Police / Digital Arrest video call threats requesting urgent RTGS transfers.',
  ];

  return (
    <div className="bg-gradient-to-r from-slate-900 via-[#173B65] to-slate-900 text-white py-2.5 px-4 overflow-hidden border-y border-slate-800 shadow-inner">
      <div className="max-w-7xl mx-auto flex items-center gap-3">
        {/* Badge */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-rose-500/20 text-rose-300 border border-rose-500/40 rounded-lg text-xs font-extrabold uppercase tracking-wider shrink-0">
          <Flame size={14} className="text-rose-400 animate-bounce" />
          <span>{lang === 'hi' ? 'लाइव अलर्ट्स' : 'LIVE ALERTS'}</span>
        </div>

        {/* Scrolling text */}
        <div className="relative flex-1 overflow-hidden h-5">
          <div className="flex items-center space-x-12 animate-marquee whitespace-nowrap text-xs text-slate-200 font-medium">
            {tickerItems.map((item, idx) => (
              <span key={idx} className="inline-flex items-center gap-2">
                <span>{item}</span>
                <span className="text-slate-600 font-mono">•</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
