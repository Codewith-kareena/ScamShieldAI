import React from 'react';
import { ClipboardPaste, Cpu, ShieldCheck, ArrowRight } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export default function HowItWorks() {
  const { lang, t } = useLanguage();

  const steps = [
    {
      step: '01',
      icon: ClipboardPaste,
      iconColor: 'bg-blue-100 text-blue-700',
      title: lang === 'hi' ? '1. सामग्री पेस्ट करें' : '1. Paste Suspicious Input',
      desc:
        lang === 'hi'
          ? 'कोई भी संदिग्ध SMS, व्हाट्सएप संदेश, निवेश विज्ञापन या वेबसाइट लिंक संबंधित स्कैनर बॉक्स में पेस्ट करें।'
          : 'Copy and paste any suspicious text message, payment link, website address, or investment promotion into the scanner.',
    },
    {
      step: '02',
      icon: Cpu,
      iconColor: 'bg-cyan-100 text-cyan-700',
      title: lang === 'hi' ? '2. गहन हीयूरिस्टिक जांच' : '2. Heuristic Analysis Engine',
      desc:
        lang === 'hi'
          ? 'हमारा नियम-आधारित इंजन मनोवैज्ञानिक दबाव, छिपे हुए फर्जी लिंक और असंभव वित्तीय वादों की तुरंत जांच करता है।'
          : 'Our rule-based engine evaluates structural patterns, psychological panic triggers, phishing infrastructure, and Ponzi mechanics.',
    },
    {
      step: '03',
      icon: ShieldCheck,
      iconColor: 'bg-emerald-100 text-emerald-700',
      title: lang === 'hi' ? '3. सुरक्षा रिपोर्ट व मार्गदर्शन' : '3. Actionable Defense Report',
      desc:
        lang === 'hi'
          ? 'तुरंत रिस्क स्कोर, हाइलाइट किए गए चेतावनी शब्द और सुरक्षित रहने के लिए व्यावहारिक कदम प्राप्त करें।'
          : 'Receive an instant risk gauge score, highlighted threat phrases with explanations, and official steps to protect your finances.',
    },
  ];

  return (
    <section className="py-16 md:py-20 bg-slate-50 border-y border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#173B65] tracking-tight">
            {lang === 'hi' ? 'ScamShield AI कैसे काम करता है' : 'How ScamShield AI Protects You'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            {lang === 'hi'
              ? 'तीन सरल और पूरी तरह से गोपनीय चरणों में पारदर्शी हीयूरिस्टिक विश्लेषण।'
              : 'Transparent, 100% private, and explainable analysis in three effortless steps.'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
          {steps.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className="card-premium p-6 bg-white flex flex-col justify-between relative hover:border-cyan-300 group"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${item.iconColor} shadow-xs`}>
                      <Icon size={24} />
                    </div>
                    <span className="text-2xl font-extrabold text-slate-200 group-hover:text-cyan-200 transition-colors font-mono">
                      {item.step}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-[#173B65]">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
