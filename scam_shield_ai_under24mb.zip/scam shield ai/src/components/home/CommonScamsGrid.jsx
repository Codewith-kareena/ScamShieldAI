import React from 'react';
import {
  CreditCard,
  Video,
  ThumbsUp,
  Coins,
  Smartphone,
  Gift,
  AlertTriangle,
  ArrowUpRight,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export default function CommonScamsGrid({ setActiveTab }) {
  const { lang, t } = useLanguage();

  const scams = [
    {
      icon: CreditCard,
      color: 'bg-rose-50 text-rose-700 border-rose-200',
      titleEn: 'Fake Bank KYC & Account Block',
      titleHi: 'फर्जी बैंक KYC और खाता बंद होने का डर',
      descEn: 'Threatens that your bank account will be frozen within 2 hours unless you update KYC via an unofficial link.',
      descHi: 'दावा किया जाता है कि लिंक पर KYC न करने पर बैंक खाता 2 घंटे में बंद हो जाएगा।',
      redFlagEn: 'Demands Aadhaar OTP or netbanking password on a third-party website.',
      redFlagHi: 'थर्ड-पार्टी वेबसाइट पर आधार OTP या नेटबैंकिंग पासवर्ड मांगना।',
    },
    {
      icon: Video,
      color: 'bg-purple-50 text-purple-700 border-purple-200',
      titleEn: 'Digital Arrest & Police Video Call',
      titleHi: 'डिजिटल अरेस्ट और फर्जी पुलिस वीडियो कॉल',
      descEn: 'Scammers pose as CBI or Police officers on Skype/WhatsApp, claiming drugs were found in your courier.',
      descHi: 'सीबीआई या पुलिस बनकर पार्सल में अवैध सामान मिलने का झूठा डर दिखाकर पैसे ऐंठना।',
      redFlagEn: 'Legitimate law enforcement NEVER conducts court trials or demands money on video calls.',
      redFlagHi: 'वास्तविक पुलिस कभी भी वीडियो कॉल पर पूछताछ या पैसे की मांग नहीं करती।',
    },
    {
      icon: ThumbsUp,
      color: 'bg-blue-50 text-blue-700 border-blue-200',
      titleEn: 'Part-Time Video Rating Job Trap',
      titleHi: 'पार्ट-टाइम यूट्यूब रेटिंग जॉब फ्रॉड',
      descEn: 'Promises ₹5,000/day for liking videos or rating hotels, later demanding prepaid deposits to release your earnings.',
      descHi: 'वीडियो लाइक करने पर भारी कमाई का वादा, बाद में पैसे निकालने के नाम पर जमा मांगना।',
      redFlagEn: 'Demands prepaid "security deposits" to unlock your accumulated profits.',
      redFlagHi: 'कमाई निकालने के लिए अग्रिम "सिक्योरिटी डिपॉजिट" की मांग करना।',
    },
    {
      icon: Coins,
      color: 'bg-amber-50 text-amber-700 border-amber-200',
      titleEn: 'High-Yield Crypto / Forex Schemes',
      titleHi: 'उच्च रिटर्न क्रिप्टो और फॉरेक्स पोंजी स्कीम',
      descEn: 'Fake trading bots or VIP Telegram channels promising guaranteed 15% daily or 500% weekly profits.',
      descHi: 'गारंटीड 15% दैनिक या 500% साप्ताहिक रिटर्न का वादा करने वाले फर्जी टेलीग्राम ग्रुप।',
      redFlagEn: 'Guaranteed high returns with "zero risk" are mathematically and legally impossible.',
      redFlagHi: 'शून्य जोखिम के साथ भारी रिटर्न का दावा पोंजी स्कीम का स्पष्ट प्रमाण है।',
    },
    {
      icon: Smartphone,
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      titleEn: 'Malicious Utility Bill APK Downloads',
      titleHi: 'खतरनाक बिजली बिल APK फाइल डाउनलोड',
      descEn: 'Electricity disconnection SMS instructing users to install an APK file that reads SMS OTPs silently.',
      descHi: 'बिजली कटने का डर दिखाकर APK इंस्टॉल करवाना, जो फोन से चुपचाप OTP चुराता है।',
      redFlagEn: 'Never install `.apk` files received over WhatsApp, SMS, or Telegram.',
      redFlagHi: 'व्हाट्सएप या SMS पर मिली किसी भी `.apk` फाइल को कभी इंस्टॉल न करें।',
    },
    {
      icon: Gift,
      color: 'bg-cyan-50 text-cyan-700 border-cyan-200',
      titleEn: 'Lottery & Reward Advance Fee',
      titleHi: 'लॉटरी और पुरस्कार अग्रिम शुल्क घोटाला',
      descEn: 'Notifies you that you won a ₹25,00,000 lottery or luxury car, requiring upfront "GST & processing fees".',
      descHi: 'लाखों की लॉटरी या कार जीतने का संदेश, जिसके लिए पहले टैक्स या फीस मांगी जाती है।',
      redFlagEn: 'Legitimate lotteries and awards deduct tax at source; they never demand money upfront.',
      redFlagHi: 'असली पुरस्कार कभी भी पहले नकद पैसे या टैक्स की मांग नहीं करते।',
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14 space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#173B65] tracking-tight">
            {lang === 'hi' ? 'प्रचलित वित्तीय घोटालों को पहचानें' : 'Recognize Modern Scam Traps'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            {lang === 'hi'
              ? 'साइबर अपराधियों द्वारा उपयोग की जाने वाली सबसे सामान्य मनोवैज्ञानिक रणनीतियों को समझें।'
              : 'Understand the most prevalent tactics used by cyber fraudsters to target everyday citizens.'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {scams.map((scam, i) => {
            const Icon = scam.icon;
            return (
              <div
                key={i}
                className="card-premium p-6 bg-slate-50/50 hover:bg-white flex flex-col justify-between border-slate-200 hover:border-slate-300 transition-all"
              >
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${scam.color} shadow-xs`}>
                      <Icon size={20} />
                    </div>
                    <h3 className="text-sm font-bold text-[#173B65] leading-snug">
                      {lang === 'hi' ? scam.titleHi : scam.titleEn}
                    </h3>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {lang === 'hi' ? scam.descHi : scam.descEn}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-200 text-[11px] text-rose-800 bg-rose-50/70 p-2.5 rounded-lg border border-rose-200 flex items-start gap-1.5">
                  <AlertTriangle size={13} className="text-rose-600 shrink-0 mt-0.5" />
                  <span>
                    <strong>{lang === 'hi' ? 'रेड फ्लैग: ' : 'Red Flag: '}</strong>
                    {lang === 'hi' ? scam.redFlagHi : scam.redFlagEn}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
