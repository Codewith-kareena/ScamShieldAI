import React from 'react';
import {
  MessageSquare,
  Globe,
  FileCheck,
  ArrowRight,
  ShieldAlert,
  Search,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export default function FeatureCards({ setActiveTab, featureCardsRef }) {
  const { lang, t } = useLanguage();

  const features = [
    {
      id: 'message',
      tab: 'message',
      icon: MessageSquare,
      iconBg: 'bg-blue-50 text-blue-700 border-blue-200',
      badge: lang === 'hi' ? 'SMS व व्हाट्सएप सुरक्षा' : 'SMS & WhatsApp Defense',
      badgeBg: 'bg-blue-50 text-blue-700',
      title: lang === 'hi' ? 'संदेश स्कैनर (Message Scanner)' : 'Suspicious Message Scanner',
      desc:
        lang === 'hi'
          ? 'SMS, व्हाट्सएप या ईमेल संदेशों का तुरंत विश्लेषण करें। घबराहट पैदा करने वाली धमकियों, OTP चोरी और फर्जी बैंक KYC संदेशों को पहचानें।'
          : 'Examine suspicious text messages, WhatsApp forwards, or phishing emails. Detects psychological urgency, OTP harvesting, fake APK links, and official impersonation.',
      bullet1: lang === 'hi' ? 'घबराहट व खाता बंद होने की धमकी' : 'Artificial Urgency & Fear Tactics',
      bullet2: lang === 'hi' ? 'OTP और पासवर्ड चोरी की मांग' : 'OTP & Credential Extraction Attempts',
      bullet3: lang === 'hi' ? 'संदिग्ध APK व फाइल लिंक' : 'Malicious APK Downloads & Links',
      btnText: lang === 'hi' ? 'संदेश स्कैनर खोलें' : 'Scan Message Now',
      gradient: 'from-blue-500/10 to-transparent',
    },
    {
      id: 'url',
      tab: 'url',
      icon: Globe,
      iconBg: 'bg-cyan-50 text-cyan-700 border-cyan-200',
      badge: lang === 'hi' ? 'वेबसाइट सुरक्षा जांच' : 'Domain Security Audit',
      badgeBg: 'bg-cyan-50 text-cyan-700',
      title: lang === 'hi' ? 'URL सुरक्षा चेकर (URL Inspector)' : 'Website URL Security Inspector',
      desc:
        lang === 'hi'
          ? 'वेबसाइट लिंक की संरचना जांचें। संदिग्ध डोमेन एक्सटेंशन (.xyz, .top), भ्रामक सबडोमेन और IP-आधारित पोर्टल का तुरंत पता लगाएं।'
          : 'Audit website URLs for deceptive top-level domains, typosquatting brand names (e.g. sbi-secure-update), unencrypted HTTP connections, and raw IP hostnames.',
      bullet1: lang === 'hi' ? 'असुरक्षित HTTP कनेक्शन' : 'Unencrypted Insecure HTTP Protocol',
      bullet2: lang === 'hi' ? 'फर्जी डोमेन (.xyz, .top)' : 'High-Risk TLDs (.xyz, .top, .click)',
      bullet3: lang === 'hi' ? 'बैंक ब्रांड स्पूफिंग' : 'Financial Brand Typosquatting',
      btnText: lang === 'hi' ? 'URL चेकर खोलें' : 'Check Website URL',
      gradient: 'from-cyan-500/10 to-transparent',
    },
    {
      id: 'claim',
      tab: 'claim',
      icon: FileCheck,
      iconBg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      badge: lang === 'hi' ? 'निवेश व पोंजी स्कीम जांच' : 'Investment & Ponzi Audit',
      badgeBg: 'bg-emerald-50 text-emerald-700',
      title: lang === 'hi' ? 'वित्तीय दावा चेकर (Claim Verifier)' : 'Financial Claim & Scheme Verifier',
      desc:
        lang === 'hi'
          ? 'निवेश विज्ञापनों और "गारंटीड रिटर्न" के दावों का ऑडिट करें। असंभव ब्याज दरों, पोंजी स्कीमों और गायब सेबी पंजीकरण को समझें।'
          : 'Evaluate investment ads, high-yield crypto schemes, and social media tips. Identifies mathematically impossible returns, Ponzi MLM mechanisms, and missing SEBI/RBI disclosures.',
      bullet1: lang === 'hi' ? 'गारंटीड व शून्य-जोखिम दावे' : 'Guaranteed & Zero-Risk Profit Claims',
      bullet2: lang === 'hi' ? 'मल्टी-लेवल पोंजी रेफरल' : 'Multi-Level Ponzi & Matrix Mechanics',
      bullet3: lang === 'hi' ? 'नियामक लाइसेंस की कमी' : 'Missing Regulatory Risk Disclosures',
      btnText: lang === 'hi' ? 'दावा सत्यापित करें' : 'Verify Financial Claim',
      gradient: 'from-emerald-500/10 to-transparent',
    },
  ];

  return (
    <section ref={featureCardsRef} className="py-16 md:py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold uppercase tracking-wider">
            <Sparkles size={13} className="text-[#16B8C4]" />
            <span>{lang === 'hi' ? 'कोर सुरक्षा मॉड्यूल' : 'Core Security Modules'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#173B65] tracking-tight">
            {lang === 'hi' ? 'व्यापक वित्तीय सुरक्षा उपकरण' : 'Three Specialized Scam Defense Tools'}
          </h2>
          <p className="text-sm sm:text-base text-slate-600 font-medium">
            {lang === 'hi'
              ? 'मनोवैज्ञानिक दबाव, भ्रामक लिंक और असंभव वित्तीय वादों को तुरंत उजागर करने के लिए निर्मित।'
              : 'Engineered with transparent heuristic rules to detect deceptive psychological triggers and technical warning signs.'}
          </p>
        </div>

        {/* 3 Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.id}
                className="card-premium flex flex-col justify-between p-7 hover:border-cyan-300 relative group overflow-hidden"
              >
                {/* Subtle top corner gradient tint */}
                <div
                  className={`absolute top-0 right-0 w-32 h-32 rounded-bl-full bg-gradient-to-bl ${card.gradient} pointer-events-none`}
                />

                <div className="space-y-4 relative z-10">
                  {/* Top Icon & Badge */}
                  <div className="flex items-center justify-between">
                    <div
                      className={`w-12 h-12 rounded-xl flex items-center justify-center border ${card.iconBg} shadow-xs group-hover:scale-110 transition-transform`}
                    >
                      <Icon size={24} />
                    </div>
                    <span className={`text-[11px] font-extrabold px-2.5 py-1 rounded-full ${card.badgeBg}`}>
                      {card.badge}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <div>
                    <h3 className="text-xl font-bold text-[#173B65] group-hover:text-cyan-700 transition-colors">
                      {card.title}
                    </h3>
                    <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                      {card.desc}
                    </p>
                  </div>

                  {/* Checklist of what it catches */}
                  <div className="pt-2 border-t border-slate-100 space-y-2 text-xs text-slate-700">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 size={14} className="text-cyan-600 shrink-0" />
                      <span>{card.bullet1}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 size={14} className="text-cyan-600 shrink-0" />
                      <span>{card.bullet2}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 size={14} className="text-cyan-600 shrink-0" />
                      <span>{card.bullet3}</span>
                    </div>
                  </div>
                </div>

                {/* Bottom CTA Button */}
                <div className="pt-6 mt-4 relative z-10">
                  <button
                    onClick={() => {
                      setActiveTab(card.tab);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="w-full py-3 px-4 bg-slate-50 hover:bg-[#173B65] text-[#173B65] hover:text-white border border-slate-200 hover:border-[#173B65] rounded-xl text-xs font-bold transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-2xs group/btn"
                  >
                    <span>{card.btnText}</span>
                    <ArrowRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
