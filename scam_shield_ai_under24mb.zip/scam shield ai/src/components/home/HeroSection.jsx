import React from 'react';
import {
  ShieldCheck,
  Zap,
  ArrowRight,
  MessageSquare,
  Globe,
  FileCheck,
  Lock,
  Sparkles,
  CheckCircle,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export default function HeroSection({ setActiveTab, onExploreClick }) {
  const { lang, t } = useLanguage();

  return (
    <section className="relative overflow-hidden bg-mesh-light py-12 md:py-20 border-b border-slate-200">
      {/* Background ambient accents */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-cyan-100/50 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 rounded-full bg-blue-100/40 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto space-y-6">
          {/* Top Tagline Pill */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-50 border border-cyan-200 text-[#173B65] shadow-xs animate-in fade-in zoom-in duration-300">
            <span className="w-2 h-2 rounded-full bg-[#16B8C4] animate-ping" />
            <span className="text-xs font-extrabold uppercase tracking-wider text-cyan-800">
              {lang === 'hi' ? '🛡️ विश्वास करने से पहले सोचें' : '🛡️ Think Before You Trust'}
            </span>
          </div>

          {/* Hero Main Heading */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-[#173B65] tracking-tight leading-[1.15]">
            {lang === 'hi' ? (
              <>
                वित्तीय धोखाधड़ी से <span className="text-[#16B8C4] underline decoration-cyan-200 underline-offset-8">एक कदम आगे</span> रहें।
              </>
            ) : (
              <>
                Stay One Step Ahead of <span className="text-[#16B8C4] underline decoration-cyan-200 underline-offset-8">Financial Scams</span>.
              </>
            )}
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg text-slate-600 font-normal leading-relaxed max-w-2xl mx-auto">
            {lang === 'hi'
              ? 'कार्रवाई करने से पहले संदिग्ध संदेशों का विश्लेषण करें, वेबसाइट के चेतावनी संकेतों की जांच करें और भ्रामक वित्तीय दावों को तुरंत समझें।'
              : 'Analyse suspicious messages, check website warning signs, and understand misleading financial claims with instant, explainable heuristic intelligence.'}
          </p>

          {/* Hero CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-4">
            <button
              onClick={() => {
                setActiveTab('message');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="w-full sm:w-auto px-7 py-3.5 bg-gradient-to-r from-[#173B65] to-[#1E4D85] hover:from-[#132F52] hover:to-[#173B65] text-white rounded-xl font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer group"
            >
              <MessageSquare size={18} className="text-cyan-300" />
              <span>{lang === 'hi' ? 'स्कैनिंग शुरू करें' : 'Start Scanning'}</span>
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={onExploreClick}
              className="w-full sm:w-auto px-7 py-3.5 bg-white hover:bg-slate-50 text-[#173B65] border border-slate-300 hover:border-slate-400 rounded-xl font-bold text-sm shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Sparkles size={16} className="text-[#16B8C4]" />
              <span>{lang === 'hi' ? 'विशेषताएं देखें' : 'Explore Features'}</span>
            </button>
          </div>

          {/* Quick Scanner Shortcut Badges */}
          <div className="pt-6 flex flex-wrap items-center justify-center gap-2 text-xs font-medium text-slate-600">
            <span className="text-slate-400 font-semibold">{lang === 'hi' ? 'त्वरित जांच:' : 'Quick Launch:'}</span>
            <button
              onClick={() => setActiveTab('message')}
              className="px-3 py-1 bg-white border border-slate-200 hover:border-cyan-400 rounded-lg text-slate-700 hover:text-[#173B65] transition-colors flex items-center gap-1.5 shadow-2xs"
            >
              <MessageSquare size={13} className="text-blue-500" />
              <span>SMS / WhatsApp</span>
            </button>
            <button
              onClick={() => setActiveTab('url')}
              className="px-3 py-1 bg-white border border-slate-200 hover:border-cyan-400 rounded-lg text-slate-700 hover:text-[#173B65] transition-colors flex items-center gap-1.5 shadow-2xs"
            >
              <Globe size={13} className="text-cyan-500" />
              <span>Website Links</span>
            </button>
            <button
              onClick={() => setActiveTab('claim')}
              className="px-3 py-1 bg-white border border-slate-200 hover:border-cyan-400 rounded-lg text-slate-700 hover:text-[#173B65] transition-colors flex items-center gap-1.5 shadow-2xs"
            >
              <FileCheck size={13} className="text-emerald-500" />
              <span>Investment Schemes</span>
            </button>
          </div>
        </div>

        {/* 4 Feature Metrics Ribbon */}
        <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
          <div className="card-premium p-4 flex items-center gap-3 bg-white">
            <div className="w-10 h-10 rounded-xl bg-cyan-50 text-cyan-700 flex items-center justify-center shrink-0">
              <ShieldCheck size={20} />
            </div>
            <div>
              <p className="text-lg font-extrabold text-[#173B65]">100%</p>
              <p className="text-xs text-slate-500 font-medium">
                {lang === 'hi' ? 'पारदर्शी नियम' : 'Explainable Rules'}
              </p>
            </div>
          </div>

          <div className="card-premium p-4 flex items-center gap-3 bg-white">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
              <Zap size={20} />
            </div>
            <div>
              <p className="text-lg font-extrabold text-[#173B65]">&lt; 0.5s</p>
              <p className="text-xs text-slate-500 font-medium">
                {lang === 'hi' ? 'त्वरित विश्लेषण' : 'Instant Analysis'}
              </p>
            </div>
          </div>

          <div className="card-premium p-4 flex items-center gap-3 bg-white">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
              <Lock size={20} />
            </div>
            <div>
              <p className="text-lg font-extrabold text-[#173B65]">0 Bytes</p>
              <p className="text-xs text-slate-500 font-medium">
                {lang === 'hi' ? 'डेटा स्टोर नहीं' : 'Data Stored'}
              </p>
            </div>
          </div>

          <div className="card-premium p-4 flex items-center gap-3 bg-white">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
              <CheckCircle size={20} />
            </div>
            <div>
              <p className="text-lg font-extrabold text-[#173B65]">24x7</p>
              <p className="text-xs text-slate-500 font-medium">
                {lang === 'hi' ? 'उपलब्ध सुरक्षा' : 'Cyber Literacy'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
