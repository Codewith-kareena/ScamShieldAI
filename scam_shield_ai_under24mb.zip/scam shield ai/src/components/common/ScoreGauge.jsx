import React from 'react';
import { useLanguage } from '../../context/LanguageContext';

export default function ScoreGauge({ score = 0, riskLevel = 'LOW', size = 140 }) {
  const { lang } = useLanguage();

  // Color configurations based on risk
  let strokeColor = '#10B981'; // Emerald
  let bgStroke = '#E2E8F0';
  let badgeColor = 'text-emerald-700 bg-emerald-50 border-emerald-200';
  let labelEn = 'Low Risk';
  let labelHi = 'सुरक्षित / कम जोखिम';

  if (score >= 60 || riskLevel === 'HIGH' || riskLevel === 'CRITICAL') {
    strokeColor = '#EF4444'; // Red
    badgeColor = 'text-rose-700 bg-rose-50 border-rose-200';
    labelEn = 'High Threat';
    labelHi = 'उच्च खतरा';
  } else if (score >= 25 || riskLevel === 'MEDIUM') {
    strokeColor = '#F59E0B'; // Amber
    badgeColor = 'text-amber-700 bg-amber-50 border-amber-200';
    labelEn = 'Suspicious';
    labelHi = 'मध्यम जोखिम';
  }

  // Circle geometry calculation
  const strokeWidth = 10;
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  // Use a 270 degree semi-circle arc for dashboard feel
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
        <svg
          width={size}
          height={size}
          viewBox={`0 0 ${size} ${size}`}
          className="transform -rotate-90"
        >
          {/* Background circle track */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={bgStroke}
            strokeWidth={strokeWidth}
            fill="transparent"
            strokeLinecap="round"
          />
          {/* Animated Value Arc */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={strokeColor}
            strokeWidth={strokeWidth}
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
          />
        </svg>

        {/* Center score readout */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="text-3xl font-extrabold text-slate-800 tracking-tight">
            {score}
          </span>
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            / 100
          </span>
        </div>
      </div>

      {/* Risk Assessment Label */}
      <div className={`mt-2 px-3 py-0.5 text-xs font-bold rounded-full border ${badgeColor}`}>
        {lang === 'hi' ? labelHi : labelEn}
      </div>
    </div>
  );
}
