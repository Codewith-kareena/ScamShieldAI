import React, { useState } from 'react';
import { AlertCircle, Info } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export default function HighlightedText({ text = '', matchedTokens = [] }) {
  const { lang } = useLanguage();
  const [activeTooltip, setActiveTooltip] = useState(null);

  if (!text) return null;

  if (!matchedTokens || matchedTokens.length === 0) {
    return (
      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 leading-relaxed font-mono text-sm whitespace-pre-wrap select-text">
        {text}
      </div>
    );
  }

  // Sort tokens by start
  const sorted = [...matchedTokens].sort((a, b) => a.start - b.start);

  const segments = [];
  let currentIndex = 0;

  sorted.forEach((token, index) => {
    // Non-highlighted preceding text
    if (token.start > currentIndex) {
      segments.push({
        type: 'text',
        content: text.substring(currentIndex, token.start),
        key: `text-${currentIndex}`,
      });
    }

    // Highlighted phrase token
    segments.push({
      type: 'token',
      content: text.substring(token.start, token.end),
      token,
      key: `token-${token.start}-${index}`,
    });

    currentIndex = token.end;
  });

  // Remaining text
  if (currentIndex < text.length) {
    segments.push({
      type: 'text',
      content: text.substring(currentIndex),
      key: `text-end-${currentIndex}`,
    });
  }

  return (
    <div className="relative">
      <div className="p-4.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 leading-relaxed font-sans text-sm md:text-base whitespace-pre-wrap select-text">
        {segments.map((seg) => {
          if (seg.type === 'text') {
            return <span key={seg.key}>{seg.content}</span>;
          }

          const isCritical = seg.token.severity === 'critical' || seg.token.severity === 'high';
          const highlightClass = isCritical
            ? 'bg-rose-100 text-rose-900 border-b-2 border-rose-500 font-semibold px-1 rounded-xs'
            : 'bg-amber-100 text-amber-900 border-b-2 border-amber-500 font-semibold px-1 rounded-xs';

          return (
            <span
              key={seg.key}
              className={`relative inline-block cursor-help transition-all hover:opacity-85 ${highlightClass}`}
              onMouseEnter={() => setActiveTooltip(seg.token)}
              onMouseLeave={() => setActiveTooltip(null)}
              onClick={() => setActiveTooltip(activeTooltip === seg.token ? null : seg.token)}
            >
              {seg.content}
            </span>
          );
        })}
      </div>

      {/* Interactive Tooltip Card on Hover / Tap */}
      {activeTooltip && (
        <div className="mt-3 p-3.5 bg-slate-900 text-white rounded-xl shadow-xl border border-slate-800 text-xs animate-in fade-in slide-in-from-top-1 duration-200">
          <div className="flex items-center gap-2 font-bold text-amber-400 mb-1">
            <AlertCircle size={15} />
            <span>
              {lang === 'hi'
                ? activeTooltip.titleHi || activeTooltip.categoryHi
                : activeTooltip.titleEn || activeTooltip.category}
            </span>
            <span className="ml-auto px-1.5 py-0.5 rounded text-[10px] uppercase font-mono tracking-wider bg-slate-800 text-slate-300">
              {activeTooltip.severity}
            </span>
          </div>
          <p className="text-slate-300 text-xs leading-relaxed">
            {lang === 'hi'
              ? `पहचाना गया वाक्यांश: "${activeTooltip.phrase}"`
              : `Flagged suspicious pattern: "${activeTooltip.phrase}"`}
          </p>
        </div>
      )}
    </div>
  );
}
