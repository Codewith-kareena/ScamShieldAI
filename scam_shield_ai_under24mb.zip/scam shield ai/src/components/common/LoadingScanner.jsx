import React, { useState, useEffect } from 'react';
import { Shield, Sparkles, Binary, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export default function LoadingScanner({ type = 'message' }) {
  const { lang } = useLanguage();
  const [stepIndex, setStepIndex] = useState(0);

  const stepsEn = [
    'Deconstructing text tokens and structural syntax...',
    'Scanning heuristic threat indicators & panic triggers...',
    'Cross-referencing credential harvesting patterns...',
    'Compiling safety checklist and risk score...',
  ];

  const stepsHi = [
    'टेक्स्ट टोकन और वाक्य संरचना का विश्लेषण...',
    'धोखाधड़ी के पैटर्न और मनोवैज्ञानिक दबाव की जांच...',
    'क्रेडेंशियल चोरी और फर्जी लिंक की पहचान...',
    'सुरक्षा चेकलिस्ट और रिस्क स्कोर तैयार किया जा रहा है...',
  ];

  const steps = lang === 'hi' ? stepsHi : stepsEn;

  useEffect(() => {
    const timer = setInterval(() => {
      setStepIndex((prev) => (prev < steps.length - 1 ? prev + 1 : prev));
    }, 400);

    return () => clearInterval(timer);
  }, [steps.length]);

  return (
    <div className="card-premium p-8 text-center flex flex-col items-center justify-center my-6 border-cyan-200 bg-gradient-to-b from-cyan-50/30 to-white">
      {/* Animated Shield Radar Pulse */}
      <div className="relative mb-5 flex items-center justify-center">
        <div className="w-20 h-20 rounded-full bg-cyan-100 flex items-center justify-center animate-ping opacity-35 absolute" />
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#173B65] to-[#16B8C4] flex items-center justify-center shadow-lg relative z-10 text-white">
          <Shield size={32} className="animate-pulse" />
        </div>
      </div>

      <h3 className="text-lg font-bold text-[#173B65] mb-2 flex items-center gap-2">
        <Sparkles size={18} className="text-[#16B8C4] animate-spin" />
        {lang === 'hi' ? 'हीयूरिस्टिक AI स्कैन जारी है...' : 'Running Heuristic Deep Scan...'}
      </h3>

      <p className="text-sm font-medium text-slate-600 mb-6 h-6 transition-all duration-300">
        {steps[stepIndex]}
      </p>

      {/* Mini Progress Dots */}
      <div className="flex items-center gap-2">
        {steps.map((_, i) => (
          <div
            key={i}
            className={`h-2 rounded-full transition-all duration-300 ${
              i <= stepIndex ? 'w-8 bg-[#16B8C4]' : 'w-2 bg-slate-200'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
