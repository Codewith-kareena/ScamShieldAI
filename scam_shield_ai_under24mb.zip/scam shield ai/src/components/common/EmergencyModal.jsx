import React from 'react';
import { PhoneCall, Globe, ShieldAlert, X, ExternalLink, AlertTriangle, Clock } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export default function EmergencyModal({ isOpen, onClose }) {
  const { lang } = useLanguage();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="card-premium max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 md:p-8 bg-white border-rose-200 shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
        >
          <X size={20} />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3.5 mb-5">
          <div className="w-12 h-12 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0 shadow-xs">
            <ShieldAlert size={26} />
          </div>
          <div>
            <h3 className="text-xl font-extrabold text-[#173B65]">
              {lang === 'hi' ? 'आपातकालीन साइबर अपराध सहायता' : 'Emergency Cyber Fraud Incident Support'}
            </h3>
            <p className="text-xs text-rose-600 font-semibold flex items-center gap-1 mt-0.5">
              <Clock size={13} />
              {lang === 'hi'
                ? 'गोल्डन आवर: पहले 2-3 घंटों में रिपोर्ट करने पर पैसे वापस मिलने की संभावना सबसे अधिक होती है।'
                : 'Golden Hour: Reporting within the first 2-3 hours maximizes chance of fund recovery.'}
            </p>
          </div>
        </div>

        {/* Priority 1: 1930 Helpline */}
        <div className="p-4 bg-gradient-to-r from-rose-50 to-amber-50 border border-rose-200 rounded-2xl mb-5">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-rose-700 bg-rose-100 px-2 py-0.5 rounded-md">
                {lang === 'hi' ? 'राष्ट्रीय आपातकालीन नंबर' : 'National Cyber Helpline (India)'}
              </span>
              <div className="text-3xl font-extrabold text-[#173B65] mt-2 tracking-tight flex items-center gap-2">
                <PhoneCall size={28} className="text-rose-600 animate-bounce" />
                1930
              </div>
              <p className="text-xs text-slate-600 mt-1">
                {lang === 'hi'
                  ? 'टोल-फ्री 24x7 राष्ट्रीय साइबर अपराध वित्तीय धोखाधड़ी हेल्पलाइन।'
                  : 'Toll-Free 24x7 National Cyber Financial Fraud Reporting Line.'}
              </p>
            </div>
            <a
              href="tel:1930"
              className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-sm font-bold shadow-md transition-all shrink-0 mt-1 flex items-center gap-1.5"
            >
              <PhoneCall size={16} />
              {lang === 'hi' ? 'अभी कॉल करें' : 'Call 1930'}
            </a>
          </div>
        </div>

        {/* Immediate 3 Action Steps */}
        <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-3">
          {lang === 'hi' ? 'तत्काल 3 कदम उठाएं' : 'Immediate 3 Action Steps:'}
        </h4>
        <div className="space-y-2.5 mb-6 text-xs text-slate-700">
          <div className="flex items-start gap-2.5 p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <span className="w-5 h-5 rounded-full bg-[#173B65] text-white flex items-center justify-center font-bold shrink-0 text-[11px]">
              1
            </span>
            <p>
              <strong>{lang === 'hi' ? 'बैंक को सूचित करें: ' : 'Freeze Accounts: '}</strong>
              {lang === 'hi'
                ? 'तुरंत अपने बैंक के कस्टमर केयर पर कॉल करके प्रभावित कार्ड, नेटबैंकिंग या UPI को ब्लॉक करवाएं।'
                : 'Immediately call your bank helpline to block the affected debit/credit card and freeze netbanking credentials.'}
            </p>
          </div>
          <div className="flex items-start gap-2.5 p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <span className="w-5 h-5 rounded-full bg-[#173B65] text-white flex items-center justify-center font-bold shrink-0 text-[11px]">
              2
            </span>
            <p>
              <strong>{lang === 'hi' ? '1930 पर कॉल करें: ' : 'Dial 1930: '}</strong>
              {lang === 'hi'
                ? 'UPI ट्रांजैक्शन ID, बैंक खाता नंबर और समय नोट करके 1930 पर शिकायत दर्ज कराएं ताकि धन निकासी रोकी जा सके।'
                : 'Report transaction reference IDs, recipient UPI address, and timestamp to 1930 so suspect accounts can be frozen.'}
            </p>
          </div>
          <div className="flex items-start gap-2.5 p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <span className="w-5 h-5 rounded-full bg-[#173B65] text-white flex items-center justify-center font-bold shrink-0 text-[11px]">
              3
            </span>
            <p>
              <strong>{lang === 'hi' ? 'लिखित शिकायत दर्ज करें: ' : 'File Formal Cyber Complaint: '}</strong>
              {lang === 'hi'
                ? 'cybercrime.gov.in पर SMS, व्हाट्सएप चैट और बैंक स्टेटमेंट के स्क्रीनशॉट के साथ लिखित शिकायत दर्ज करें।'
                : 'Submit detailed complaint with screenshots of SMS, chat history, and bank statement at cybercrime.gov.in.'}
            </p>
          </div>
        </div>

        {/* Official Web Portals Directory */}
        <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-3">
          {lang === 'hi' ? 'आधिकारिक सरकारी पोर्टल' : 'Official Government Reporting Portals'}
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-5 text-xs">
          <a
            href="https://cybercrime.gov.in"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-cyan-50 hover:border-cyan-300 transition-all text-slate-800 font-semibold"
          >
            <span>cybercrime.gov.in</span>
            <ExternalLink size={14} className="text-cyan-600" />
          </a>
          <a
            href="https://sachet.rbi.org.in"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-cyan-50 hover:border-cyan-300 transition-all text-slate-800 font-semibold"
          >
            <span>RBI Sachet Portal</span>
            <ExternalLink size={14} className="text-cyan-600" />
          </a>
          <a
            href="https://scores.gov.in"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-cyan-50 hover:border-cyan-300 transition-all text-slate-800 font-semibold"
          >
            <span>SEBI SCORES Portal</span>
            <ExternalLink size={14} className="text-cyan-600" />
          </a>
          <a
            href="https://sancharsaathi.gov.in/sfc"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-cyan-50 hover:border-cyan-300 transition-all text-slate-800 font-semibold"
          >
            <span>Chakshu (Fraud Mobile/SMS)</span>
            <ExternalLink size={14} className="text-cyan-600" />
          </a>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-bold text-sm transition-colors"
        >
          {lang === 'hi' ? 'बंद करें' : 'Close Window'}
        </button>
      </div>
    </div>
  );
}
