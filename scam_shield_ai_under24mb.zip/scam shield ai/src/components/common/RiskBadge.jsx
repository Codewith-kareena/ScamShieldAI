import React from 'react';
import { ShieldCheck, AlertTriangle, AlertOctagon, ShieldAlert } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export default function RiskBadge({ level = 'LOW', size = 'md', className = '' }) {
  const { lang, t } = useLanguage();

  const configs = {
    LOW: {
      bg: 'bg-emerald-50 border-emerald-200 text-emerald-800',
      iconBg: 'bg-emerald-100 text-emerald-700',
      icon: ShieldCheck,
      textEn: 'LOW RISK',
      textHi: 'निम्न जोखिम',
      subEn: 'Safe / Normal Indicators',
      subHi: 'सामान्य / सुरक्षित संकेतक',
    },
    MEDIUM: {
      bg: 'bg-amber-50 border-amber-200 text-amber-800',
      iconBg: 'bg-amber-100 text-amber-700',
      icon: AlertTriangle,
      textEn: 'MEDIUM RISK',
      textHi: 'मध्यम जोखिम',
      subEn: 'Suspicious Elements Flagged',
      subHi: 'संदिग्ध तत्व पाए गए',
    },
    HIGH: {
      bg: 'bg-rose-50 border-rose-300 text-rose-800',
      iconBg: 'bg-rose-100 text-rose-700',
      icon: AlertOctagon,
      textEn: 'HIGH RISK',
      textHi: 'उच्च जोखिम',
      subEn: 'Severe Scam Markers Detected',
      subHi: 'गंभीर धोखाधड़ी के संकेत',
    },
    CRITICAL: {
      bg: 'bg-red-50 border-red-300 text-red-900',
      iconBg: 'bg-red-200 text-red-800',
      icon: ShieldAlert,
      textEn: 'CRITICAL THREAT',
      textHi: 'अत्यंत गंभीर खतरा',
      subEn: 'Immediate Fraud Pattern',
      subHi: 'तत्काल वित्तीय फ्रॉड',
    },
  };

  const config = configs[level] || configs.LOW;
  const Icon = config.icon;

  const sizeClasses = {
    sm: 'px-2.5 py-1 text-xs gap-1.5 font-semibold',
    md: 'px-3.5 py-1.5 text-sm gap-2 font-bold',
    lg: 'px-4 py-2 text-base gap-2.5 font-extrabold',
  };

  const iconSizes = {
    sm: 14,
    md: 18,
    lg: 22,
  };

  return (
    <span
      className={`inline-flex items-center rounded-full border shadow-xs transition-all ${config.bg} ${sizeClasses[size]} ${className}`}
    >
      <span className={`p-1 rounded-full flex items-center justify-center ${config.iconBg}`}>
        <Icon size={iconSizes[size]} strokeWidth={2.5} />
      </span>
      <span>{lang === 'hi' ? config.textHi : config.textEn}</span>
    </span>
  );
}
