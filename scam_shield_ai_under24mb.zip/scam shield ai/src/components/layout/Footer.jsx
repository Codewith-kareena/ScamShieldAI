import React from 'react';
import { Shield, Lock, ExternalLink, Heart, AlertCircle, PhoneCall } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export default function Footer({ setActiveTab, onOpenEmergency }) {
  const { lang } = useLanguage();

  return (
    <footer className="bg-slate-50 border-t border-slate-200 text-slate-600 mt-20">
      {/* Top advisory band */}
      <div className="border-b border-slate-200 py-6 px-4 bg-cyan-50/40">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-cyan-100 text-cyan-800 flex items-center justify-center shrink-0">
              <Lock size={18} />
            </div>
            <div>
              <p className="text-xs font-bold text-[#173B65]">
                {lang === 'hi' ? '100% क्लाइंट-साइड गोपनीयता' : '100% Client-Side Privacy Guarantee'}
              </p>
              <p className="text-[11px] text-slate-500">
                {lang === 'hi'
                  ? 'आपके द्वारा दर्ज किए गए संदेश या URL किसी सर्वर पर सहेजे नहीं जाते हैं।'
                  : 'Your submitted messages, claims, and URLs are evaluated locally and never saved to remote servers.'}
              </p>
            </div>
          </div>
          <button
            onClick={onOpenEmergency}
            className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-bold shadow-xs transition-colors"
          >
            <PhoneCall size={14} className="text-rose-600" />
            {lang === 'hi' ? 'राष्ट्रीय साइबर आपातकालीन निर्देशिका' : 'National Cyber Emergency Contacts'}
          </button>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: Brand Info */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#173B65] to-[#16B8C4] flex items-center justify-center text-white shadow-xs">
                <Shield size={18} />
              </div>
              <span className="text-lg font-extrabold text-[#173B65] tracking-tight">
                ScamShield<span className="text-[#16B8C4]">AI</span>
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium leading-relaxed">
              {lang === 'hi'
                ? '“विश्वास करने से पहले सोचें” — वित्तीय धोखाधड़ी के खिलाफ आपका रीयल-टाइम सुरक्षा कवच।'
                : '“Think Before You Trust.” — Empowering internet users with transparent heuristic scam defense tools.'}
            </p>
            <div className="pt-1">
              <span className="inline-block text-[11px] font-bold px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg">
                Light-Theme Modern Edition
              </span>
            </div>
          </div>

          {/* Col 2: Core Tools */}
          <div>
            <h4 className="text-xs font-bold text-[#173B65] uppercase tracking-wider mb-3">
              {lang === 'hi' ? 'सुरक्षा उपकरण' : 'Defense Tools'}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => {
                    setActiveTab('message');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#173B65] hover:underline"
                >
                  {lang === 'hi' ? 'संदेश स्कैनर' : 'Message Scanner'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveTab('url');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#173B65] hover:underline"
                >
                  {lang === 'hi' ? 'URL सुरक्षा चेकर' : 'URL Security Inspector'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveTab('claim');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#173B65] hover:underline"
                >
                  {lang === 'hi' ? 'वित्तीय दावा चेकर' : 'Financial Claim Verifier'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveTab('dashboard');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#173B65] hover:underline"
                >
                  {lang === 'hi' ? 'सत्र एनालिटिक्स' : 'Session Analytics Dashboard'}
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Awareness & Education */}
          <div>
            <h4 className="text-xs font-bold text-[#173B65] uppercase tracking-wider mb-3">
              {lang === 'hi' ? 'जागरूकता एवं क्विज़' : 'Awareness & Guide'}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => {
                    setActiveTab('knowledge');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#173B65] hover:underline"
                >
                  {lang === 'hi' ? 'Scam IQ इंटरैक्टिव क्विज़' : 'Scam IQ Interactive Quiz'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveTab('knowledge');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#173B65] hover:underline"
                >
                  {lang === 'hi' ? '5 गोल्डन रूल्स (रेड फ्लैग्स)' : '5 Golden Rules & Red Flags'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveTab('about');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#173B65] hover:underline"
                >
                  {lang === 'hi' ? 'पारदर्शी हीयूरिस्टिक्स' : 'Transparent Heuristics & Privacy'}
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Official Helplines */}
          <div>
            <h4 className="text-xs font-bold text-[#173B65] uppercase tracking-wider mb-3">
              {lang === 'hi' ? 'आधिकारिक हेल्पलाइन (भारत)' : 'Official Indian Helplines'}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a
                  href="tel:1930"
                  className="flex items-center gap-1.5 text-rose-700 font-bold hover:underline"
                >
                  <span>National Cyber Helpline: 1930</span>
                </a>
              </li>
              <li>
                <a
                  href="https://cybercrime.gov.in"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 hover:text-[#173B65] hover:underline"
                >
                  <span>cybercrime.gov.in</span>
                  <ExternalLink size={11} className="text-slate-400" />
                </a>
              </li>
              <li>
                <a
                  href="https://sachet.rbi.org.in"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 hover:text-[#173B65] hover:underline"
                >
                  <span>RBI Sachet Portal</span>
                  <ExternalLink size={11} className="text-slate-400" />
                </a>
              </li>
              <li>
                <a
                  href="https://scores.gov.in"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 hover:text-[#173B65] hover:underline"
                >
                  <span>SEBI SCORES Portal</span>
                  <ExternalLink size={11} className="text-slate-400" />
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Legal Band */}
        <div className="mt-10 pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-400 gap-3">
          <p>© 2026 ScamShield AI. Developed for Financial Cyber Literacy & Scam Prevention.</p>
          <p className="flex items-center gap-1">
            Built with <Heart size={12} className="text-rose-500 fill-rose-500" /> for cyber safety awareness.
          </p>
        </div>
      </div>
    </footer>
  );
}
