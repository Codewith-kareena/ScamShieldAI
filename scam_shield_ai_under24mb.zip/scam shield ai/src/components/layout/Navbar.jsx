import React, { useState } from 'react';
import {
  Shield,
  MessageSquare,
  Globe,
  FileCheck,
  LayoutDashboard,
  HelpCircle,
  Info,
  PhoneCall,
  Menu,
  X,
  Languages,
  Activity,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useSession } from '../../context/SessionContext';

export default function Navbar({ activeTab, setActiveTab, onOpenEmergency }) {
  const { lang, toggleLanguage, t } = useLanguage();
  const { stats } = useSession();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navLinks = [
    { id: 'home', labelKey: 'nav.home', icon: Shield },
    { id: 'message', labelKey: 'nav.messageScanner', icon: MessageSquare },
    { id: 'url', labelKey: 'nav.urlChecker', icon: Globe },
    { id: 'claim', labelKey: 'nav.claimChecker', icon: FileCheck },
    { id: 'dashboard', labelKey: 'nav.dashboard', icon: LayoutDashboard },
    { id: 'knowledge', labelKey: 'nav.knowledge', icon: HelpCircle },
    { id: 'about', labelKey: 'nav.about', icon: Info },
  ];

  const handleNavClick = (id) => {
    setActiveTab(id);
    setMobileOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top micro-bar with emergency alert & language notice */}
      <div className="bg-[#173B65] text-white text-[11px] py-1 px-4 sm:px-8 flex items-center justify-between font-medium">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="hidden sm:inline">
            {lang === 'hi'
              ? 'राष्ट्रीय साइबर अपराध हेल्पलाइन: 1930 (24x7 टोल फ्री)'
              : 'National Cyber Crime Helpline: 1930 (24x7 Toll Free)'}
          </span>
          <span className="sm:hidden">Helpline: 1930</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-cyan-300 font-bold hidden md:inline">
            “Think Before You Trust.”
          </span>
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1 bg-white/10 hover:bg-white/20 px-2 py-0.5 rounded text-xs transition-colors cursor-pointer"
            title="Toggle English / Hindi"
          >
            <Languages size={12} />
            <span className="font-bold">{lang === 'en' ? '🇮🇳 हिंदी' : '🇬🇧 English'}</span>
          </button>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#173B65] to-[#16B8C4] flex items-center justify-center text-white shadow-md group-hover:scale-105 transition-transform">
              <Shield size={22} className="group-hover:rotate-6 transition-transform" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-extrabold text-[#173B65] tracking-tight">
                  ScamShield<span className="text-[#16B8C4]">AI</span>
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 bg-cyan-50 text-cyan-700 border border-cyan-200 rounded-md">
                  v2.0
                </span>
              </div>
              <p className="text-[10px] text-slate-500 font-semibold tracking-wide hidden sm:block">
                {lang === 'hi' ? 'विश्वास करने से पहले सोचें' : 'Think Before You Trust'}
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center gap-1">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = activeTab === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                    isActive
                      ? 'bg-cyan-50 text-[#173B65] border border-cyan-200 shadow-xs'
                      : 'text-slate-600 hover:text-[#173B65] hover:bg-slate-100'
                  }`}
                >
                  <Icon size={15} className={isActive ? 'text-[#16B8C4]' : 'text-slate-400'} />
                  {t(link.labelKey)}
                </button>
              );
            })}
          </nav>

          {/* Action CTAs */}
          <div className="hidden sm:flex items-center gap-2.5">
            {/* Session analysis pill */}
            <button
              onClick={() => handleNavClick('dashboard')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#173B65] text-xs font-bold border border-slate-200 transition-colors"
              title="View session analytics"
            >
              <Activity size={14} className="text-[#16B8C4]" />
              <span>
                {stats.totalScans} {lang === 'hi' ? 'स्कैन' : 'Scans'}
              </span>
            </button>

            {/* Emergency Hotline Button */}
            <button
              onClick={onOpenEmergency}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-extrabold shadow-xs transition-all hover:scale-102"
            >
              <PhoneCall size={14} className="text-rose-600 animate-pulse" />
              <span>1930</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-2 xl:hidden">
            <button
              onClick={onOpenEmergency}
              className="p-2 bg-rose-50 text-rose-700 rounded-xl border border-rose-200 sm:hidden"
            >
              <PhoneCall size={16} />
            </button>
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="p-2 rounded-xl text-slate-700 hover:bg-slate-100 border border-slate-200"
            >
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav Drawer */}
      {mobileOpen && (
        <div className="xl:hidden bg-white border-b border-slate-200 px-4 pt-2 pb-4 space-y-1 shadow-lg animate-in slide-in-from-top-2">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-bold transition-all ${
                  isActive
                    ? 'bg-cyan-50 text-[#173B65] border border-cyan-200'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Icon size={18} className={isActive ? 'text-[#16B8C4]' : 'text-slate-400'} />
                {t(link.labelKey)}
              </button>
            );
          })}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
            <button
              onClick={toggleLanguage}
              className="flex-1 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5"
            >
              <Languages size={14} />
              {lang === 'en' ? '🇮🇳 Switch to हिंदी' : '🇬🇧 Switch to English'}
            </button>
            <button
              onClick={() => {
                setMobileOpen(false);
                onOpenEmergency();
              }}
              className="flex-1 py-2 rounded-xl bg-rose-600 text-white font-bold text-xs flex items-center justify-center gap-1.5"
            >
              <PhoneCall size={14} />
              1930 Helpline
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
