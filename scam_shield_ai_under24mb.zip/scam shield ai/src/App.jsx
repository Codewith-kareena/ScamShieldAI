import React, { useState, useRef } from 'react';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { SessionProvider } from './context/SessionContext';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import ToastContainer from './components/common/ToastContainer';
import EmergencyModal from './components/common/EmergencyModal';

// Home Components
import HeroSection from './components/home/HeroSection';
import ScamTrendsTicker from './components/home/ScamTrendsTicker';
import FeatureCards from './components/home/FeatureCards';
import HowItWorks from './components/home/HowItWorks';
import CommonScamsGrid from './components/home/CommonScamsGrid';

// Scanner Components
import MessageScanner from './components/scanners/MessageScanner';
import UrlChecker from './components/scanners/UrlChecker';
import ClaimChecker from './components/scanners/ClaimChecker';

// Dashboard & Educational
import AnalyticsDashboard from './components/dashboard/AnalyticsDashboard';
import RedFlagsGuide from './components/educational/RedFlagsGuide';
import AboutView from './components/educational/AboutView';

function MainApp() {
  const [activeTab, setActiveTab] = useState('home');
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);
  const featureCardsRef = useRef(null);

  const handleExploreClick = () => {
    if (activeTab !== 'home') {
      setActiveTab('home');
      setTimeout(() => {
        featureCardsRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      featureCardsRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-800 flex flex-col font-sans selection:bg-cyan-500 selection:text-white">
      {/* Navbar with active tab state and emergency modal trigger */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenEmergency={() => setIsEmergencyOpen(true)}
      />

      {/* Main Tab Content */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <div>
            <ScamTrendsTicker />
            <HeroSection
              setActiveTab={setActiveTab}
              onExploreClick={handleExploreClick}
            />
            <FeatureCards
              setActiveTab={setActiveTab}
              featureCardsRef={featureCardsRef}
            />
            <HowItWorks />
            <CommonScamsGrid setActiveTab={setActiveTab} />
          </div>
        )}

        {activeTab === 'message' && <MessageScanner />}

        {activeTab === 'url' && <UrlChecker />}

        {activeTab === 'claim' && <ClaimChecker />}

        {activeTab === 'dashboard' && (
          <AnalyticsDashboard setActiveTab={setActiveTab} />
        )}

        {activeTab === 'knowledge' && (
          <RedFlagsGuide onOpenEmergency={() => setIsEmergencyOpen(true)} />
        )}

        {activeTab === 'about' && (
          <AboutView onOpenEmergency={() => setIsEmergencyOpen(true)} />
        )}
      </main>

      {/* Footer */}
      <Footer
        setActiveTab={setActiveTab}
        onOpenEmergency={() => setIsEmergencyOpen(true)}
      />

      {/* Global Toast Container */}
      <ToastContainer />

      {/* Emergency Helpline 1930 Modal */}
      <EmergencyModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <SessionProvider>
        <MainApp />
      </SessionProvider>
    </LanguageProvider>
  );
}
